// Content script that runs on all pages to provide AI assistance and Moodle quiz bypass

console.log('🔵 QuizHelper content script loaded on:', window.location.href);
console.log('🔵 Extension is working - try Ctrl+G to test!');
console.log('🔵 Content script version: 2.1.0 - Fixed Ctrl+G interception');

// Global error handler to catch undefined property access
window.addEventListener('error', function(e) {
  if (e.message && e.message.includes("Cannot read properties of undefined")) {
    console.error('🚨 CAUGHT UNDEFINED PROPERTY ERROR:', e.message);
    console.error('🚨 Error at:', e.filename, 'line:', e.lineno);
    console.error('🚨 Stack trace:', e.error ? e.error.stack : 'No stack trace');
    
    // Try to prevent the error from showing the popup
    e.preventDefault();
    return true;
  }
});

// Also catch unhandled promise rejections
window.addEventListener('unhandledrejection', function(e) {
  if (e.reason && e.reason.message && e.reason.message.includes("Cannot read properties of undefined")) {
    console.error('🚨 CAUGHT UNDEFINED PROPERTY ERROR IN PROMISE:', e.reason.message);
    console.error('🚨 Stack trace:', e.reason.stack);
    
    // Prevent the error from bubbling up
    e.preventDefault();
    return true;
  }
});

// Test if the extension is working
setTimeout(() => {
  console.log('QuizHelper extension test - if you see this, the content script is working');
}, 1000);

// Check for context invalidation
function isContextValid() {
  try {
    return chrome.runtime && chrome.runtime.id;
  } catch (e) {
    return false;
  }
}

// Handle context invalidation with user-friendly message
function handleContextInvalidation() {
  if (!isContextValid()) {
    console.warn('Extension context invalidated - page needs refresh');
    displayError('Extension was updated. Please refresh this page to continue using QuizHelper.');
    return false;
  }
  return true;
}

// Page type detection will be handled in the initialize() function

// Prevent duplicate requests
let isProcessingRequest = false;

// Increment daily query count (placeholder function)
function incrementQueryCount() {
  try {
    console.log('Query count incremented');
    // This could be expanded to track usage statistics
  } catch (e) {
    console.log('Failed to increment query count:', e.message);
  }
}

// Test background script connection
async function testBackgroundConnection() {
  return new Promise((resolve) => {
    try {
      // Set a timeout to prevent hanging
      const timeout = setTimeout(() => {
        console.error('Background script connection test timed out');
        resolve(false);
      }, 3000); // 3 second timeout
      
      chrome.runtime.sendMessage({ type: 'PING' }, (response) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) {
          console.error('Background script error:', chrome.runtime.lastError);
          resolve(false);
        } else if (response && response.success) {
          console.log('Background script is alive:', response.message);
          resolve(true);
        } else {
          console.error('Background script not responding properly');
          resolve(false);
        }
      });
    } catch (error) {
      console.error('Error testing background connection:', error);
      resolve(false);
    }
  });
}

// Centralized AI request handler
async function handleAIRequest() {
  console.log('=== handleAIRequest CALLED ===');
  
  // Check for context invalidation first
  if (!handleContextInvalidation()) {
    return;
  }
  
  // Prevent duplicate requests
  if (isProcessingRequest) {
    console.log('Request already in progress, ignoring duplicate');
    return;
  }
  
  isProcessingRequest = true;
  console.log('Processing request...');
  
  try {
    // Check if Chrome APIs are available
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      console.error('Chrome APIs not available');
      displayError('Chrome extension APIs not available. Please refresh the page.');
      isProcessingRequest = false;
      return;
    }
    
    // Test background script connection first (with timeout)
    console.log('Testing background script connection...');
    const isBackgroundAlive = await Promise.race([
      testBackgroundConnection(),
      new Promise(resolve => setTimeout(() => {
        console.warn('Background connection test taking too long, proceeding anyway...');
        resolve(true); // Proceed anyway
      }, 5000))
    ]);
    
    if (!isBackgroundAlive) {
      console.warn('Background script connection test failed, but proceeding anyway...');
      // Don't block the request - proceed anyway
    }
    
    console.log('Chrome APIs available, extracting content...');
    
    // Get selected text or page content
    const selectedText = window.getSelection().toString().trim();
    let content;
    
    if (selectedText) {
      console.log('Using selected text:', selectedText);
      content = { text: selectedText, context: 'selected text' };
    } else {
      console.log('No selection, extracting page content...');
      // Extract main content from page
      content = extractPageContent();
      console.log('Extracted content:', content);
    }
    
    console.log('Extracting images...');
    // Extract visible images and take screenshot
    let images = [];
    try {
      images = await extractVisibleImages();
      console.log('Found', images.length, 'images');
    } catch (e) {
      console.error('Error extracting images:', e);
      images = []; // Continue without images
    }
    
    console.log('Capturing screenshot...');
    // Capture screenshot with timeout to prevent hanging
    const screenshot = await Promise.race([
      captureViewportScreenshot(),
      new Promise(resolve => setTimeout(() => {
        console.log('Screenshot timeout - proceeding without screenshot');
        resolve(null);
      }, 1000)) // 1 second timeout
    ]);
    console.log('Screenshot captured:', screenshot ? 'YES' : 'NO');
    
    // Show loading indicator
    showLoadingOverlay();
    
    // Send to background script with error handling
    try {
      console.log('=== SENDING MESSAGE TO BACKGROUND SCRIPT ===');
      console.log('Message type:', 'ANALYZE_CONTENT');
      console.log('Content:', content);
      console.log('Content length:', content?.text?.length || 0);
      console.log('Images:', images);
      console.log('Images count:', images?.length || 0);
      console.log('Screenshot:', screenshot ? 'YES' : 'NO');
      
      // Ensure all data is valid before sending
      const safeContent = content || { text: '', context: 'unknown' };
      const safeImages = Array.isArray(images) ? images : [];
      const safeScreenshot = screenshot || null;
      const safePageUrl = window.location.href || 'unknown';
      
      console.log('Safe data being sent:', { safeContent, safeImages, safeScreenshot, safePageUrl });
      
      // Set a timeout to detect if callback never fires
      const callbackTimeout = setTimeout(() => {
        console.error('❌ CALLBACK TIMEOUT - Background script not responding after 10 seconds');
        console.error('This means the background script either crashed or is not receiving messages');
        hideLoadingOverlay();
        isProcessingRequest = false;
        displayError('Background script not responding. Try reloading the extension.');
      }, 10000);
      
      try {
        chrome.runtime.sendMessage({
          type: 'ANALYZE_CONTENT',
          data: { content: safeContent, images: safeImages, screenshot: safeScreenshot, pageUrl: safePageUrl }
        }, (response) => {
          clearTimeout(callbackTimeout);
          console.log('=== MESSAGE CALLBACK TRIGGERED ===');
          hideLoadingOverlay();
          isProcessingRequest = false; // Reset flag
          
          // Check for Chrome runtime errors
          if (chrome.runtime.lastError) {
            console.error('Chrome runtime error:', chrome.runtime.lastError);
            console.error('Error message:', chrome.runtime.lastError.message);
            displayError('Extension context invalidated. Please reload the page.');
            return;
          }
          
          console.log('Received response:', response);
          
          if (response && response.error) {
            console.error('API Error:', response.error);
            displayError(response.error);
          } else if (response && response.answer) {
            console.log('Success:', { model: response.model, answerLength: response.answer.length });
            displayAIResponse(response.answer, false, response.model);
            // Increment daily query count (placeholder function)
            incrementQueryCount();
          } else {
            console.error('Unexpected response format:', response);
            displayError('Unexpected response from extension');
          }
        });
      } catch (sendError) {
        clearTimeout(callbackTimeout);
        hideLoadingOverlay();
        isProcessingRequest = false;
        console.error('Failed to send message:', sendError);
        displayError('Extension context invalidated. Please reload the page.');
      }
    } catch (error) {
      isProcessingRequest = false; // Reset flag on error
      hideLoadingOverlay();
      console.error('AI request failed:', error);
      displayError('Failed to process request: ' + error.message);
    }
  } catch (error) {
    isProcessingRequest = false; // Reset flag on error
    hideLoadingOverlay();
    console.error('AI request failed (outer):', error);
    displayError('Failed to process request: ' + error.message);
  }
}

// Universal Ctrl+G listener for AI assistance (capture phase to intercept before Chrome)
document.addEventListener('keydown', async (e) => {
  console.log('🔵 Key pressed:', e.key, 'Ctrl:', e.ctrlKey, 'Shift:', e.shiftKey);
  
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    console.log('🔵 Ctrl+G detected - preventing default IMMEDIATELY');
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    
    console.log('🔵 Calling handleAIRequest');
    try {
      await handleAIRequest();
    } catch (error) {
      console.error('🔴 Error in handleAIRequest:', error);
      displayError('Error processing request: ' + error.message);
    }
    return false;
  }
}, true); // TRUE = capture phase (intercept before Chrome handlers)

// Also add a more aggressive keydown listener
window.addEventListener('keydown', async (e) => {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    console.log('🔵 Window Ctrl+G detected - preventing default');
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    
    console.log('🔵 Calling handleAIRequest from window listener');
    try {
      await handleAIRequest();
    } catch (error) {
      console.error('🔴 Error in handleAIRequest from window:', error);
      displayError('Error processing request: ' + error.message);
    }
    return false;
  }
}, true);

// Listen for messages from background script (context menu)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ANALYZE_SELECTION') {
    // Prevent duplicate requests
    if (isProcessingRequest) {
      console.log('Request already in progress, ignoring context menu request');
      return;
    }
    
    isProcessingRequest = true;
    showLoadingOverlay();
    
    const content = { text: message.text, context: 'selected text' };
    
    // Check Chrome API availability
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      hideLoadingOverlay();
      isProcessingRequest = false;
      displayError('Chrome extension APIs not available. Please refresh the page.');
      return;
    }
    
    // Capture screenshot for context menu requests too
    captureViewportScreenshot().then(screenshot => {
    
      chrome.runtime.sendMessage({
        type: 'ANALYZE_CONTENT',
        data: { content, images: [], screenshot, pageUrl: window.location.href }
      }, (response) => {
        hideLoadingOverlay();
        isProcessingRequest = false; // Reset flag
        
        if (response && response.error) {
          displayError(response.error);
        } else if (response && response.answer) {
          displayAIResponse(response.answer, false, response.model);
        }
      });
    });
  } else if (message.type === 'ANALYZE_PAGE') {
    // Handle page analysis request (right-click context menu)
    if (isProcessingRequest) {
      console.log('Request already in progress, ignoring page analysis request');
      return;
    }
    
    // Simulate Ctrl+Shift+G press
    const event = new KeyboardEvent('keydown', {
      key: 'G',
      ctrlKey: true,
      shiftKey: true,
      bubbles: true
    });
    document.dispatchEvent(event);
  } else if (message.type === 'SAVE_PROCESSING_REQUEST') {
    // Save processing request data to a file for Python to read
    try {
      // Create a blob with the data
      const blob = new Blob([message.data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Create a download link
      const a = document.createElement('a');
      a.href = url;
      a.download = 'moodle_processing_request.json';
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      console.log('Processing request saved to moodle_processing_request.json');
      sendResponse({ success: true });
    } catch (error) {
      console.error('Error saving processing request:', error);
      sendResponse({ success: false, error: error.message });
    }
  }
});

// Removed fallback listener - the capture phase listener above handles all pages

function extractPageContent() {
  // Get ONLY what's visible in the current viewport
  console.log('Extracting VISIBLE viewport content only...');
  
  const isQuizPage = isMoodleQuizOrTestPage();
  console.log('Is quiz/test page:', isQuizPage);
  
  if (isQuizPage) {
    // For quiz pages, extract question-specific content
    return extractQuizContent();
  } else {
    // For regular pages, extract general visible text
    return extractGeneralContent();
  }
}

function extractQuizContent() {
  const allText = [];
  const seenText = new Set();
  
  // Target specific question containers (not sidebar links)
  const questionContainers = document.querySelectorAll('.que, .question, [class*="question-container"], [role="region"]');
  
  console.log('Found question containers:', questionContainers.length);
  
  for (const container of questionContainers) {
    // Check if container is actually visible in viewport
    const rect = container.getBoundingClientRect();
    const style = window.getComputedStyle(container);
    
    // Must be visible and within viewport - STRICT CHECK
    // Also check that it's not tiny (like a sidebar link)
    const isVisible = rect.top >= 0 && rect.top < window.innerHeight && 
                     rect.left >= 0 && rect.left < window.innerWidth &&
                     rect.height > 50 && // Must be at least 50px tall (real questions, not links)
                     rect.width > 200 && // Must be at least 200px wide (not sidebar)
                     style.display !== 'none' &&
                     style.visibility !== 'hidden' &&
                     style.opacity !== '0';
    
    if (!isVisible) continue;
    
    // Get text content from this question container
    const text = container.textContent.trim();
    
    // Only include if it's substantial and not a duplicate
    if (text && text.length > 50 && !seenText.has(text)) {
      allText.push(text);
      seenText.add(text);
      console.log('Found visible question:', text.substring(0, 80) + '...');
    }
  }
  
  console.log('Found visible questions:', allText.length);
  
  // Join all visible content together
  const finalText = allText.join('\n\n---NEXT QUESTION---\n\n');
  console.log('VISIBLE TEXT BEING SENT TO GEMINI (first 300 chars):', finalText.substring(0, 300) + '...');
  
  return {
    text: finalText,
    context: 'visible quiz questions on screen'
  };
}

function extractGeneralContent() {
  // For non-quiz pages, extract all visible meaningful text
  const textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, td, th, div, span, a, button, label, input, textarea');
  const allText = [];
  const seenText = new Set();
  
  for (const element of textElements) {
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    // Check if visible in viewport
    const isVisible = rect.top >= 0 && rect.top < window.innerHeight && 
                     rect.left >= 0 && rect.left < window.innerWidth &&
                     rect.height > 0 && rect.width > 0 &&
                     style.display !== 'none' &&
                     style.visibility !== 'hidden' &&
                     style.opacity !== '0';
    
    if (!isVisible) continue;
    
    // Get direct text only (not from children)
    let text = '';
    for (const node of element.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        text += node.textContent.trim() + ' ';
      }
    }
    text = text.trim();
    
    // Add meaningful text
    if (text && text.length > 5 && !seenText.has(text)) {
      allText.push(text);
      seenText.add(text);
    }
  }
  
  console.log('Found visible text elements:', allText.length);
  
  // Join and limit to reasonable size
  const finalText = allText.join(' ').substring(0, 5000);
  console.log('VISIBLE TEXT BEING SENT TO GEMINI (first 200 chars):', finalText.substring(0, 200) + '...');
  
  return {
    text: finalText,
    context: 'visible page content'
  };
}

async function extractVisibleImages() {
  const images = [];
  
  try {
    const imgElements = document.querySelectorAll('img');
    console.log(`Found ${imgElements.length} image elements`);
    
    for (const img of imgElements) {
      try {
        // Check if image is visible in viewport
        const rect = img.getBoundingClientRect();
        const isVisible = rect.top >= 0 && rect.top <= window.innerHeight && 
                         rect.left >= 0 && rect.left <= window.innerWidth &&
                         rect.width > 50 && rect.height > 50; // Skip small icons
        
        if (!isVisible) {
          continue;
        }
        
        // Check if image has valid src
        if (!img.src || img.src.startsWith('data:')) {
          console.log('Skipping image with invalid src:', img.src);
          continue;
        }
        
        console.log('Processing image:', img.src.substring(0, 50) + '...');
        const base64 = await imageToBase64(img);
        images.push(base64);
        console.log(`Successfully converted image ${images.length}`);
        
        if (images.length >= 3) {
          console.log('Reached image limit (3), stopping');
          break;
        }
      } catch (e) {
        console.log('Failed to convert image:', e.message);
        // Continue with other images
      }
    }
  } catch (e) {
    console.error('Error in extractVisibleImages:', e);
  }
  
  console.log(`Successfully extracted ${images.length} images`);
  return images;
}

async function captureViewportScreenshot() {
  try {
    console.log('Attempting to capture screenshot using chrome.tabs API...');
    
    // Use Chrome's built-in screenshot API instead of html2canvas
    return new Promise((resolve) => {
      console.log('Sending CAPTURE_SCREENSHOT message to background script...');
      
      // Add timeout to prevent hanging
      const timeout = setTimeout(() => {
        console.log('Screenshot capture timeout, proceeding without screenshot');
        resolve(null);
      }, 800); // 800ms timeout
      
      chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT' }, (response) => {
        clearTimeout(timeout);
        console.log('Received screenshot response:', response);
        
        if (chrome.runtime.lastError) {
          console.error('Chrome runtime error during screenshot:', chrome.runtime.lastError);
          console.error('Error message:', chrome.runtime.lastError.message);
          resolve(null);
          return;
        }
        
        if (!response) {
          console.error('No response received from background script for screenshot');
          resolve(null);
          return;
        }
        
        if (response.error) {
          console.error('Screenshot capture error from background:', response.error);
          resolve(null);
          return;
        }
        
        if (response && response.screenshot) {
          console.log('Screenshot captured successfully via Chrome API, length:', response.screenshot.length);
          resolve(response.screenshot);
        } else {
          console.log('Screenshot capture failed - no screenshot data in response');
          resolve(null);
        }
      });
    });
    
  } catch (error) {
    console.error('Screenshot capture error:', error);
    return null;
  }
}

async function imageToBase64(img) {
  return new Promise((resolve, reject) => {
    try {
      // Validate image element
      if (!img || !img.src) {
        reject(new Error('Invalid image element'));
        return;
      }
      
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Cannot get canvas context'));
        return;
      }
      
      // Get image dimensions with fallbacks
      const width = img.naturalWidth || img.width || img.clientWidth || 100;
      const height = img.naturalHeight || img.height || img.clientHeight || 100;
      
      // Validate dimensions
      if (width <= 0 || height <= 0) {
        reject(new Error('Invalid image dimensions'));
        return;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      img.onload = () => {
        try {
          ctx.drawImage(img, 0, 0);
          const dataURL = canvas.toDataURL('image/png');
          const base64 = dataURL.split(',')[1]; // Remove data:image/png;base64, prefix
          if (base64) {
            resolve(base64);
          } else {
            reject(new Error('Failed to extract base64 data'));
          }
        } catch (e) {
          reject(new Error('Failed to draw image to canvas: ' + e.message));
        }
      };
      
      img.onerror = () => reject(new Error('Failed to load image: ' + img.src));
      
      // If image is already loaded
      if (img.complete && img.naturalWidth > 0) {
        img.onload();
      }
    } catch (e) {
      reject(new Error('Image processing error: ' + e.message));
    }
  });
}

function showLoadingOverlay() {
  // Remove any existing overlay
  const existing = document.getElementById('gemini-loading-overlay');
  if (existing) existing.remove();
  
  const overlay = document.createElement('div');
  overlay.id = 'gemini-loading-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 20px;
    border-radius: 8px;
    z-index: 2147483647;
    font-family: Arial, sans-serif;
    font-size: 14px;
    text-align: center;
  `;
  
  const loadingContent = document.createElement('div');
  loadingContent.innerHTML = `
    <div style="margin-bottom: 10px;">🤖 Asking Gemini AI...</div>
    <div style="font-size: 12px; color: #ccc;">Finding best available model...</div>
  `;
  overlay.appendChild(loadingContent);
  
  document.body.appendChild(overlay);
}

function hideLoadingOverlay() {
  const overlay = document.getElementById('gemini-loading-overlay');
  if (overlay) overlay.remove();
}

function displayError(error) {
  displayAIResponse(`❌ Error: ${error}`, true);
}

function displayAIResponse(answer, isError = false, model = null) {
  // Remove any existing overlay
  const existing = document.getElementById('gemini-response-overlay');
  if (existing) existing.remove();
  
  // Create overlay backdrop
  const backdrop = document.createElement('div');
  backdrop.id = 'gemini-response-overlay';
  backdrop.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
  
  // Create response container
  const container = document.createElement('div');
  container.style.cssText = `
    background: white;
    border-radius: 12px;
    padding: 24px;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    margin: 20px;
  `;
  
  // Title
  const title = document.createElement('div');
  let titleText = isError ? '❌ Error' : '🤖 Gemini AI Response';
  if (model && !isError) {
    titleText += ` (${model})`;
  }
  title.textContent = titleText;
  title.style.cssText = `
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 16px;
    color: ${isError ? '#d93025' : '#1a73e8'};
  `;
  
  // Response text (selectable)
  const responseText = document.createElement('div');
  responseText.textContent = answer;
  responseText.style.cssText = `
    font-size: 14px;
    line-height: 1.6;
    color: #333;
    margin-bottom: 16px;
    user-select: text;
    white-space: pre-wrap;
  `;
  
  // Bottom controls
  const controls = document.createElement('div');
  controls.style.cssText = `
    display: flex;
    justify-content: space-between;
    align-items: center;
  `;
  
  // Timer (only show if not error)
  const timer = document.createElement('div');
  timer.style.cssText = `
    font-size: 12px;
    color: #666;
  `;
  
  // Add Escape key hint
  const escapeHint = document.createElement('div');
  escapeHint.textContent = 'Press Escape to close';
  escapeHint.style.cssText = `
    font-size: 11px;
    color: #999;
    font-style: italic;
    margin-top: 4px;
  `;
  
  // Keep Open button
  const keepOpenBtn = document.createElement('button');
  keepOpenBtn.textContent = isError ? 'Close' : 'Keep Open';
  keepOpenBtn.style.cssText = `
    background: ${isError ? '#d93025' : '#1a73e8'};
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
  `;
  
  let timeLeft = 60;
  let keepOpen = false;
  let countdownInterval;
  
  if (!isError) {
    timer.textContent = `Auto-closing in ${timeLeft} seconds...`;
  }
  
  keepOpenBtn.addEventListener('click', () => {
    if (isError) {
      backdrop.remove();
    } else {
      keepOpen = !keepOpen;
      if (keepOpen) {
        keepOpenBtn.textContent = 'Close';
        keepOpenBtn.style.background = '#d93025';
        timer.textContent = 'Window will stay open';
        clearInterval(countdownInterval);
      } else {
        backdrop.remove();
        clearInterval(countdownInterval);
      }
    }
  });
  
  // Countdown (only if not error)
  if (!isError) {
    countdownInterval = setInterval(() => {
      if (keepOpen) return;
      timeLeft--;
      timer.textContent = `Auto-closing in ${timeLeft} seconds...`;
      if (timeLeft <= 0) {
        backdrop.remove();
        clearInterval(countdownInterval);
      }
    }, 1000);
  }
  
  // Close on backdrop click
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      backdrop.remove();
      if (countdownInterval) clearInterval(countdownInterval);
    }
  });
  
  // Close on Escape key
  const escapeHandler = (e) => {
    if (e.key === 'Escape') {
      backdrop.remove();
      if (countdownInterval) clearInterval(countdownInterval);
      document.removeEventListener('keydown', escapeHandler);
    }
  };
  document.addEventListener('keydown', escapeHandler);
  
  // Assemble
  if (!isError) controls.appendChild(timer);
  controls.appendChild(keepOpenBtn);
  container.appendChild(title);
  container.appendChild(responseText);
  container.appendChild(controls);
  container.appendChild(escapeHint);
  backdrop.appendChild(container);
  document.body.appendChild(backdrop);
}

// Disable secure window prevention features (for Moodle quiz pages only)
function disableSecureWindowFeatures() {
  console.log('Disabling secure window prevention features...');
  
  // Only run this on Moodle pages to prevent conflicts
  if (!window.location.hostname.includes('moodle')) {
    console.log('Skipping security bypass - not a Moodle page');
    return;
  }
  
  // 1. Re-enable right-click context menu
  document.addEventListener('contextmenu', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 2. Re-enable keyboard shortcuts (F12, Ctrl+Shift+I, etc.)
  document.addEventListener('keydown', function(e) {
    // Allow F12 (Developer Tools)
    if (e.key === 'F12') {
      e.stopPropagation();
      e.stopImmediatePropagation();
      return true;
    }
    
    // Allow Ctrl+Shift+I (Developer Tools)
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
      e.stopPropagation();
      e.stopImmediatePropagation();
      return true;
    }
    
    // Allow Ctrl+U (View Source)
    if (e.ctrlKey && e.key === 'u') {
      e.stopPropagation();
      e.stopImmediatePropagation();
      return true;
    }
    
    // Allow Ctrl+Shift+J (Console)
    if (e.ctrlKey && e.shiftKey && e.key === 'J') {
      e.stopPropagation();
      e.stopImmediatePropagation();
      return true;
    }
  }, true);
  
  // 3. Remove or disable mouse event restrictions
  document.addEventListener('mousedown', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  document.addEventListener('mouseup', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 4. Disable text selection restrictions
  document.addEventListener('selectstart', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 5. Remove copy/paste restrictions
  document.addEventListener('copy', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  document.addEventListener('paste', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 6. Disable drag restrictions
  document.addEventListener('dragstart', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 7. Remove focus/blur restrictions that might disable functionality
  document.addEventListener('blur', function(e) {
    e.stopPropagation();
    e.stopImmediatePropagation();
    return true;
  }, true);
  
  // 8. Override any existing event listeners that disable functionality
  const originalAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, listener, options) {
    // Block certain event types that might disable functionality
    const blockedEvents = ['beforeunload', 'unload'];
    if (blockedEvents.includes(type)) {
      console.log(`Blocked ${type} event listener that might disable functionality`);
      return;
    }
    return originalAddEventListener.call(this, type, listener, options);
  };
  
  // 9. Remove any existing restrictions on the document
  document.oncontextmenu = null;
  document.onselectstart = null;
  document.ondragstart = null;
  document.onkeydown = null;
  document.onmousedown = null;
  
  // 10. Override any existing JavaScript that might disable functionality
  const originalConsoleLog = console.log;
  console.log = function(...args) {
    // Allow console.log to work normally
    return originalConsoleLog.apply(console, args);
  };
  
  console.log('Secure window prevention features disabled successfully');
}

// Comprehensive security script disabling (for Moodle pages only)
function disableSecurityScripts() {
  console.log('Disabling Moodle security scripts...');
  
  // Only run this on Moodle pages to prevent conflicts
  if (!window.location.hostname.includes('moodle')) {
    console.log('Skipping security script disabling - not a Moodle page');
    return;
  }
  
  // Override common security functions
  window.alert = function(message) {
    console.log('Alert blocked:', message);
    return;
  };
  
  window.confirm = function(message) {
    console.log('Confirm blocked:', message);
    return true;
  };
  
  // Disable common security event handlers
  const securityHandlers = [
    'oncontextmenu', 'onselectstart', 'ondragstart', 'onkeydown', 
    'onmousedown', 'onmouseup', 'oncopy', 'onpaste', 'oncut',
    'onbeforeunload', 'onunload', 'onblur', 'onfocus'
  ];
  
  securityHandlers.forEach(handler => {
    document[handler] = null;
    window[handler] = null;
  });
  
  // Override common security properties
  Object.defineProperty(document, 'oncontextmenu', {
    get: () => null,
    set: () => {}
  });
  
  Object.defineProperty(document, 'onselectstart', {
    get: () => null,
    set: () => {}
  });
  
  // Disable common security CSS
  const style = document.createElement('style');
  style.textContent = `
    * {
      -webkit-user-select: text !important;
      -moz-user-select: text !important;
      -ms-user-select: text !important;
      user-select: text !important;
      -webkit-touch-callout: default !important;
      -webkit-tap-highlight-color: transparent !important;
    }
    body {
      -webkit-user-select: text !important;
      -moz-user-select: text !important;
      -ms-user-select: text !important;
      user-select: text !important;
    }
  `;
  document.head.appendChild(style);
  
  // Override common security methods
  if (window.addEventListener) {
    const originalAddEventListener = window.addEventListener;
    window.addEventListener = function(type, listener, options) {
      if (type === 'beforeunload' || type === 'unload') {
        console.log(`Blocked ${type} event listener`);
        return;
      }
      return originalAddEventListener.call(this, type, listener, options);
    };
  }
  
  // Disable common security variables
  window.MoodleSecurity = false;
  window.QuizSecurity = false;
  window.TestSecurity = false;
  
  console.log('Security scripts disabled successfully');
}

// Create a status indicator
function createStatusIndicator() {
  const indicator = document.createElement('div');
  indicator.id = 'security-bypass-indicator';
  indicator.style.cssText = `
    position: fixed;
    top: 10px;
    right: 10px;
    background: #4CAF50;
    color: white;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-family: Arial, sans-serif;
    z-index: 10000;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
  `;
  indicator.textContent = '🔓 Security Bypass Active';
  document.body.appendChild(indicator);
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    if (indicator.parentNode) {
      indicator.parentNode.removeChild(indicator);
    }
  }, 3000);
}

// Remove any existing warning popups about disabled functionality
function removeWarningPopups() {
  // Look for common warning popup selectors
  const warningSelectors = [
    '.alert-warning',
    '.modal-warning',
    '.popup-warning',
    '[class*="warning"]',
    '[class*="disabled"]',
    '[class*="restricted"]'
  ];
  
  warningSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      const text = element.textContent.toLowerCase();
      if (text.includes('disabled') || text.includes('restricted') || 
          text.includes('not allowed') || text.includes('functionality')) {
        console.log('Removing warning popup:', element);
        element.remove();
      }
    });
  });
}

// Override any JavaScript that might show "functionality disabled" messages
function overrideWarningMessages() {
  // Override common alert/confirm functions that might show warnings
  const originalAlert = window.alert;
  const originalConfirm = window.confirm;
  
  window.alert = function(message) {
    const msg = message.toLowerCase();
    if (msg.includes('disabled') || msg.includes('restricted') || 
        msg.includes('not allowed') || msg.includes('functionality')) {
      console.log('Blocked warning alert:', message);
      return;
    }
    return originalAlert.call(window, message);
  };
  
  window.confirm = function(message) {
    const msg = message.toLowerCase();
    if (msg.includes('disabled') || msg.includes('restricted') || 
        msg.includes('not allowed') || msg.includes('functionality')) {
      console.log('Blocked warning confirm:', message);
      return true; // Always return true to bypass restrictions
    }
    return originalConfirm.call(window, message);
  };
}

// Preserve test timer functionality
function preserveTestTimer() {
  // Look for timer elements and ensure they're not disabled
  const timerSelectors = [
    '[class*="timer"]',
    '[class*="countdown"]',
    '[id*="timer"]',
    '[id*="countdown"]',
    '.quiz-timer',
    '.test-timer'
  ];
  
  timerSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      // Remove any disabled attributes
      element.removeAttribute('disabled');
      element.removeAttribute('readonly');
      
      // Ensure timer can run
      if (element.style) {
        element.style.pointerEvents = 'auto';
        element.style.userSelect = 'auto';
      }
    });
  });
  
  // Look for timer-related JavaScript and ensure it's not blocked
  const scripts = document.querySelectorAll('script');
  scripts.forEach(script => {
    if (script.textContent.includes('timer') || script.textContent.includes('countdown')) {
      // Re-enable timer scripts if they were disabled
      console.log('Preserving timer functionality');
    }
  });
}

// Initialize security bypass
function initializeSecurityBypass() {
  console.log('Initializing Moodle Quiz Security Bypass...');
  
  // Disable secure window features
  disableSecureWindowFeatures();
  
  // Remove warning popups
  removeWarningPopups();
  
  // Override warning messages
  overrideWarningMessages();
  
  // Preserve test timer
  preserveTestTimer();
  
  // Show status indicator
  createStatusIndicator();
  
  console.log('Security bypass initialized successfully');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}

function initialize() {
  console.log('🔍 INITIALIZE FUNCTION CALLED');
  console.log('🔍 URL:', window.location.href);
  console.log('🔍 Protocol:', window.location.protocol);
  
  // ALWAYS try to add the resource extraction button - let the page detection handle it
  console.log('Attempting to add resource extraction button...');
  initializeResourceExtraction();
  
  // Skip security bypass for local files (no active security to bypass)
  if (window.location.protocol === 'file:') {
    console.log('Local file - security bypass not needed');
    return;
  }
  
  // Check if this is a Moodle quiz/test page (by content, not just URL)
  if (isMoodleQuizOrTestPage()) {
    console.log('Moodle quiz/test page detected - initializing security bypass');
    initializeSecurityBypass();
    
    // Re-run bypass periodically to catch any new restrictions
    setInterval(() => {
      removeWarningPopups();
      preserveTestTimer();
      disableSecurityScripts();
    }, 2000);
  }
  
  // Initialize resource extraction on course pages (both live and local)
  const isLiveMoodleCourse = window.location.hostname.includes('moodle') && 
                             window.location.pathname.includes('/course/view.php');
  const isCoursePageByContent = isMoodleCoursePage();
  
  console.log('🔍 LIVE MOODLE COURSE CHECK:');
  console.log('🔍 Hostname includes moodle:', window.location.hostname.includes('moodle'));
  console.log('🔍 Pathname includes /course/view.php:', window.location.pathname.includes('/course/view.php'));
  console.log('🔍 Is live Moodle course:', isLiveMoodleCourse);
  console.log('🔍 Is course page by content:', isCoursePageByContent);
  
  if (isLiveMoodleCourse || isCoursePageByContent) {
    console.log('Moodle course page detected - initializing resource extraction');
    initializeResourceExtraction();
  } else {
    console.log('NOT a Moodle course page - no resource extraction button');
  }
}

function isMoodleCoursePage() {
  // Simplified detection - just check for common Moodle elements
  const hasActivityGrids = document.querySelectorAll('div.activity-grid').length > 0;
  const hasActivityIcons = document.querySelectorAll('img.activityicon').length > 0;
  const hasResourceLinks = document.querySelectorAll('a[href*="mod/resource/view.php"]').length > 0;
  const hasCourseStructure = document.querySelectorAll('.course-content, .course-section, .activity').length > 0;
  const hasMoodleElements = document.querySelectorAll('[class*="moodle"], [id*="moodle"]').length > 0;
  
  // Also check page text for course indicators
  const pageText = document.body.innerText.toLowerCase();
  const hasCourseText = pageText.includes('course') || pageText.includes('syllabus') || pageText.includes('resources');
  
  console.log('🔍 MOODLE COURSE PAGE DETECTION:');
  console.log('🔍 URL:', window.location.href);
  console.log('🔍 Has activity grids:', hasActivityGrids);
  console.log('🔍 Has activity icons:', hasActivityIcons);
  console.log('🔍 Has resource links:', hasResourceLinks);
  console.log('🔍 Has course structure:', hasCourseStructure);
  console.log('🔍 Has Moodle elements:', hasMoodleElements);
  console.log('🔍 Has course text:', hasCourseText);
  
  const isCoursePage = hasActivityGrids || hasActivityIcons || hasResourceLinks || hasCourseStructure || hasMoodleElements || hasCourseText;
  console.log('🔍 Final result - Is course page:', isCoursePage);
  
  return isCoursePage;
}

function isMoodleQuizOrTestPage() {
  // Check for specific Moodle quiz/test page indicators (more restrictive)
  const quizIndicators = [
    'flag question', 'question text', 'answer question', 'submit quiz',
    'quiz attempt', 'test attempt', 'quiz navigation', 'question navigation'
  ];
  
  const pageText = document.body.innerText.toLowerCase();
  const hasQuizContent = quizIndicators.some(indicator => pageText.includes(indicator));
  
  // Check for specific Moodle quiz elements (more restrictive)
  const hasQuizElements = document.querySelectorAll(
    '.que, .question, .quiz, .test, .qnbutton, .qn_buttons, .quiznav, .attempt, [id*="attempt"], [id*="question-"]'
  ).length > 0;
  
  // Check for quiz navigation or attempt elements
  const hasQuizNavigation = document.querySelectorAll(
    '.qnbutton, .qn_buttons, .quiznav, .attempt, [id*="attempt"], [class*="quiz-"], [class*="test-"]'
  ).length > 0;
  
  // Check if we're on a quiz/test URL
  const isQuizUrl = window.location.pathname.includes('/mod/quiz/') || 
                   window.location.pathname.includes('/mod/test/') ||
                   window.location.pathname.includes('/quiz/') ||
                   window.location.pathname.includes('/test/');
  
  return hasQuizContent || hasQuizElements || hasQuizNavigation || isQuizUrl;
}

// Resource extraction functionality for Moodle course pages
function initializeResourceExtraction() {
  console.log('Initializing resource extraction for Moodle course page');
  
  // Add resource extraction button to the page
  addResourceExtractionButton();
  
  // Listen for resource extraction requests
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_COURSE_RESOURCES') {
      extractCourseResources().then(sendResponse);
      return true; // Keep channel open for async response
    }
  });
}

function addResourceExtractionButton() {
  // Don't show button on Google AI Studio pages or other non-Moodle sites
  if (window.location.hostname.includes('aistudio.google.com') || 
      window.location.hostname.includes('google.com') ||
      window.location.hostname.includes('github.com') ||
      (!window.location.hostname.includes('moodle') && window.location.protocol !== 'file:')) {
    console.log('🔍 Not a Moodle page - skipping resource extraction button');
    return;
  }
  
  console.log('🔍 Adding resource extraction button to page');
  
  // Create floating button for resource extraction
  const button = document.createElement('button');
  button.id = 'moodle-resource-extractor';
  button.innerHTML = '📚 Extract Study Resources';
  button.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 25px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
  
  button.addEventListener('mouseenter', () => {
    button.style.transform = 'translateY(-2px)';
    button.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.3)';
  });
  
  button.addEventListener('mouseleave', () => {
    button.style.transform = 'translateY(0)';
    button.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.2)';
  });
  
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.innerHTML = '⏳ Extracting...';
    
    try {
      const resources = await extractCourseResources();
      displayResourceResults(resources);
    } catch (error) {
      console.error('Resource extraction failed:', error);
      displayError('Failed to extract resources: ' + error.message);
    } finally {
      button.disabled = false;
      button.innerHTML = '📚 Extract Study Resources';
    }
  });
  
  document.body.appendChild(button);
}

async function extractCourseResources() {
  console.log('Extracting course resources from activity-grid sections...');
  
  const resources = {
    pdfs: [],           // PDF documents for download
    powerpoints: [],    // PowerPoint presentations for download  
    documents: [],      // Word documents for download
    youtubeVideos: [],  // YouTube lecture videos for transcript extraction
    courseInfo: {}
  };
  
  // Extract course information
  const courseTitle = document.querySelector('title')?.textContent || 'Unknown Course';
  const courseUrl = window.location.href;
  
  resources.courseInfo = {
    title: courseTitle,
    url: courseUrl,
    extractedAt: new Date().toISOString()
  };
  
  // Find all activity-grid divs
  const activityGrids = document.querySelectorAll('div.activity-grid');
  console.log(`Found ${activityGrids.length} activity-grid sections`);
  
  for (const grid of activityGrids) {
    // Find the activityicon img within this grid
    const iconImg = grid.querySelector('img.activityicon');
    if (!iconImg) continue;
    
    const iconSrc = iconImg.getAttribute('src') || '';
    
    // Find the associated aalink stretched-link anchor
    const resourceLink = grid.querySelector('a.aalink.stretched-link');
    if (!resourceLink) continue;
    
    const href = resourceLink.getAttribute('href');
    const text = resourceLink.textContent.trim();
    
    if (!href) continue;
    
    const resourceType = determineResourceType(iconSrc, text);
    
    if (resourceType) {
      const resource = {
        title: text,
        url: href.startsWith('http') ? href : new URL(href, window.location.origin).href,
        type: resourceType,
        section: getResourceSection(resourceLink)
      };
      
      // Categorize by type
      switch (resourceType) {
        case 'pdf':
          resources.pdfs.push(resource);
          break;
        case 'powerpoint':
          resources.powerpoints.push(resource);
          break;
        case 'document':
          resources.documents.push(resource);
          break;
        case 'youtube':
          resources.youtubeVideos.push(resource);
          break;
      }
      
      console.log(`Found ${resourceType}: ${text}`);
    }
  }
  
  console.log('Extracted resources:', resources);
  return resources;
}

function getResourceSection(linkElement) {
  // Try to find which section this resource belongs to
  const sectionElement = linkElement.closest('[id*="section"]');
  if (sectionElement) {
    const sectionTitle = sectionElement.querySelector('.sectionname, .section-title, h3');
    return sectionTitle ? sectionTitle.textContent.trim() : 'Unknown Section';
  }
  return 'Unknown Section';
}

function determineResourceType(iconSrc, linkText) {
  const iconSrcLower = iconSrc.toLowerCase();
  const linkTextLower = linkText.toLowerCase();
  
  // Check for PDF files
  if (iconSrcLower.includes('pdf?filter')) {
    return 'pdf';
  }
  
  // Check for PowerPoint files
  if (iconSrcLower.includes('powerpoint?filter')) {
    return 'powerpoint';
  }
  
  // Check for Word documents
  if (iconSrcLower.includes('document?filter')) {
    return 'document';
  }
  
  // Check for YouTube videos (monologo icon + "lecture" in text)
  if (iconSrcLower.includes('monologo?filter') && linkTextLower.includes('lecture')) {
    return 'youtube';
  }
  
  return null;
}

function isPowerPointOrPDF(title, url) {
  const titleLower = title.toLowerCase();
  const urlLower = url.toLowerCase();
  
  // Check for PowerPoint indicators
  const pptIndicators = [
    'ppt', 'powerpoint', 'slides', 'presentation', 'lecture slides'
  ];
  
  // Check for PDF indicators
  const pdfIndicators = [
    'pdf', 'document', 'handout', 'reading'
  ];
  
  return pptIndicators.some(indicator => titleLower.includes(indicator)) ||
         pdfIndicators.some(indicator => titleLower.includes(indicator));
}

function isYouTubeVideo(title, url) {
  const titleLower = title.toLowerCase();
  const urlLower = url.toLowerCase();
  
  const youtubeIndicators = [
    'youtube', 'youtu.be', 'video', 'lecture', 'watch'
  ];
  
  return youtubeIndicators.some(indicator => 
    titleLower.includes(indicator) || urlLower.includes(indicator)
  );
}

function displayResourceResults(resources) {
  // Remove any existing resource results
  const existing = document.getElementById('resource-results-overlay');
  if (existing) existing.remove();
  
  // Create overlay
  const overlay = document.createElement('div');
  overlay.id = 'resource-results-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    z-index: 20000;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
  
  // Create results container
  const container = document.createElement('div');
  container.style.cssText = `
    background: white;
    border-radius: 12px;
    padding: 24px;
    max-width: 800px;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    margin: 20px;
  `;
  
  // Title
  const title = document.createElement('h2');
  title.textContent = '📚 Extracted Study Resources';
  title.style.cssText = `
    margin: 0 0 20px 0;
    color: #1a73e8;
    font-size: 24px;
  `;
  
  // Course info
  const courseInfo = document.createElement('div');
  courseInfo.style.cssText = `
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 14px;
  `;
  courseInfo.innerHTML = `
    <strong>Course:</strong> ${resources.courseInfo.title}<br>
    <strong>URL:</strong> ${resources.courseInfo.url}<br>
    <strong>Extracted:</strong> ${new Date(resources.courseInfo.extractedAt).toLocaleString()}
  `;
  
  // Results sections
  let resultsHTML = '';
  
  if (resources.powerpoints.length > 0) {
    resultsHTML += `
      <div style="margin-bottom: 20px;">
        <h3 style="color: #d93025; margin-bottom: 10px;">📄 PowerPoints & PDFs (${resources.powerpoints.length})</h3>
        <div style="max-height: 200px; overflow-y: auto;">
          ${resources.powerpoints.map(resource => `
            <div style="padding: 8px; border: 1px solid #e0e0e0; border-radius: 4px; margin-bottom: 8px;">
              <strong>${resource.title}</strong><br>
              <small>Section: ${resource.section} | <a href="${resource.url}" target="_blank">View Resource</a></small>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
  
  if (resources.youtubeVideos.length > 0) {
    resultsHTML += `
      <div style="margin-bottom: 20px;">
        <h3 style="color: #ff0000; margin-bottom: 10px;">🎥 YouTube Videos (${resources.youtubeVideos.length})</h3>
        <div style="max-height: 200px; overflow-y: auto;">
          ${resources.youtubeVideos.map(resource => `
            <div style="padding: 8px; border: 1px solid #e0e0e0; border-radius: 4px; margin-bottom: 8px;">
              <strong>${resource.title}</strong><br>
              <small>Section: ${resource.section} | <a href="${resource.url}" target="_blank">View Video</a></small>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
  
  // No otherResources in our new structure - we have specific categories
  
  // Action buttons
  const actions = document.createElement('div');
  actions.style.cssText = `
    display: flex;
    gap: 12px;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #e0e0e0;
  `;
  
  const processButton = document.createElement('button');
  processButton.textContent = '🚀 Process Resources';
  processButton.style.cssText = `
    background: #1a73e8;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
  `;
  
  const closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.cssText = `
    background: #666;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    cursor: pointer;
  `;
  
  processButton.addEventListener('click', () => {
    processResources(resources);
  });
  
  closeButton.addEventListener('click', () => {
    overlay.remove();
  });
  
  actions.appendChild(processButton);
  actions.appendChild(closeButton);
  
  // Assemble
  container.appendChild(title);
  container.appendChild(courseInfo);
  container.innerHTML += resultsHTML;
  container.appendChild(actions);
  overlay.appendChild(container);
  
  // Close on backdrop click
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      overlay.remove();
    }
  });
  
  document.body.appendChild(overlay);
}

async function processResources(resources) {
  console.log('Processing resources for backend processing...');
  
  // Send resources to background script for processing
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    displayError('Chrome extension APIs not available. Please refresh the page.');
    return;
  }
  
  chrome.runtime.sendMessage({
    type: 'PROCESS_COURSE_RESOURCES',
    data: resources
  }, (response) => {
    if (response && response.success) {
      displayAIResponse('✅ Resources sent for processing! Check your StudyAutomation system for downloaded and transcribed materials.', false, 'Resource Processor');
    } else {
      displayError('Failed to process resources: ' + (response?.error || 'Unknown error'));
    }
  });
}