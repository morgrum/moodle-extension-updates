// Background service worker for QuizHelper Chrome Extension

// Model limits based on Google AI API tiers - EXACT values from your screenshot
const MODEL_LIMITS = {
    // Free Tier limits (from Google AI Studio screenshot - EXACT values)
    free: {
        'gemini-2.5-flash': { daily: 250, rpm: 10 },
        'gemini-2.5-pro': { daily: 50, rpm: 2 },
        'gemini-2.0-flash-exp': { daily: 50, rpm: 10 },
        'gemini-2.0-flash-lite': { daily: 200, rpm: 30 },
        'gemini-2.0-flash-preview-image-generation': { daily: 100, rpm: 10 },
        'gemini-2.0-flash': { daily: 200, rpm: 15 },
        'gemini-2.5-flash-lite': { daily: 1000, rpm: 15 },
        'gemini-2.5-flash-tts': { daily: 15, rpm: 3 },
        'gemini-robotics-er-1.5-preview': { daily: 250, rpm: 10 },
        'gemma-3-12b': { daily: 14400, rpm: 30 },
        'gemma-3-1b': { daily: 14400, rpm: 30 },
        'gemma-3-27b': { daily: 14400, rpm: 30 },
        'gemma-3-2b': { daily: 14400, rpm: 30 },
        'gemma-3-4b': { daily: 14400, rpm: 30 },
        'learnlm-2.0-flash-experimental': { daily: 1500, rpm: 15 }
    },
    // Tier 1 (Paid) limits - estimated based on typical Google scaling
    tier1: {
        'gemini-flash-latest': { daily: 10000, rpm: 4000 },
        'gemini-pro-latest': { daily: 10000, rpm: 150 },
        'gemini-2.5-flash': { daily: 10000, rpm: 4000 },
        'gemini-2.5-pro': { daily: 10000, rpm: 150 },
        'gemini-2.5-flash-lite': { daily: 10000, rpm: 4000 },
        'gemini-2.0-flash': { daily: 10000, rpm: 4000 },
        'gemini-2.0-flash-lite': { daily: 10000, rpm: 4000 },
        'gemma-3-1b': { daily: 50000, rpm: 1000 },
        'gemma-3-2b': { daily: 50000, rpm: 1000 },
        'gemma-3-4b': { daily: 50000, rpm: 1000 },
        'gemma-3-12b': { daily: 50000, rpm: 1000 },
        'gemma-3-27b': { daily: 50000, rpm: 1000 },
        'learnlm-2.0-flash-experimental': { daily: 50000, rpm: 1000 }
    },
    // Tier 2 limits
    tier2: {
        'gemini-flash-latest': { daily: 50000, rpm: 20000 },
        'gemini-pro-latest': { daily: 50000, rpm: 1000 },
        'gemini-2.5-flash': { daily: 50000, rpm: 20000 },
        'gemini-2.5-pro': { daily: 50000, rpm: 1000 },
        'gemini-2.5-flash-lite': { daily: 50000, rpm: 20000 },
        'gemini-2.0-flash': { daily: 50000, rpm: 20000 },
        'gemini-2.0-flash-lite': { daily: 50000, rpm: 20000 },
        'gemma-3-1b': { daily: 100000, rpm: 2000 },
        'gemma-3-2b': { daily: 100000, rpm: 2000 },
        'gemma-3-4b': { daily: 100000, rpm: 2000 },
        'gemma-3-12b': { daily: 100000, rpm: 2000 },
        'gemma-3-27b': { daily: 100000, rpm: 2000 },
        'learnlm-2.0-flash-experimental': { daily: 100000, rpm: 2000 }
    },
    // Tier 3 limits (no daily limit)
    tier3: {
        'gemini-flash-latest': { daily: null, rpm: 30000 },
        'gemini-pro-latest': { daily: null, rpm: 2000 },
        'gemini-2.5-flash': { daily: null, rpm: 30000 },
        'gemini-2.5-pro': { daily: null, rpm: 2000 },
        'gemini-2.5-flash-lite': { daily: null, rpm: 30000 },
        'gemini-2.0-flash': { daily: null, rpm: 30000 },
        'gemini-2.0-flash-lite': { daily: null, rpm: 30000 },
        'gemma-3-1b': { daily: null, rpm: 5000 },
        'gemma-3-2b': { daily: null, rpm: 5000 },
        'gemma-3-4b': { daily: null, rpm: 5000 },
        'gemma-3-12b': { daily: null, rpm: 5000 },
        'gemma-3-27b': { daily: null, rpm: 5000 },
        'learnlm-2.0-flash-experimental': { daily: null, rpm: 5000 }
    }
};

// Function to detect user tier based on API key behavior
async function detectUserTier(apiKey) {
  // Default to free tier, will be updated based on actual API behavior
  return 'free';
}

// Function to get model limit based on model name and tier
function getModelLimit(modelName, tier) {
    const limits = MODEL_LIMITS[tier] || MODEL_LIMITS.free;
    
    // Check for exact model name match first
    if (limits[modelName]) {
        return limits[modelName].daily || 1000;
    }
    
    // Check for specific model patterns with correct limits
    if (modelName.includes('2.5-flash') || modelName.includes('2.5-flash-latest')) {
        return 250; // Correct limit for 2.5 Flash models
    } else if (modelName.includes('2.5-pro') || modelName.includes('2.5-pro-latest')) {
        return 50; // Correct limit for 2.5 Pro models
    } else if (modelName.includes('2.5-flash-lite')) {
        return 1000; // Correct limit for 2.5 Flash Lite
    } else if (modelName.includes('2.0-flash')) {
        return 200; // Correct limit for 2.0 Flash models
    } else if (modelName.includes('2.0-flash-lite')) {
        return 200; // Correct limit for 2.0 Flash Lite
    } else if (modelName.includes('gemma-3')) {
        return 14400; // Correct limit for Gemma 3 models
    } else if (modelName.includes('learnlm-2.0-flash-experimental')) {
        return 1500; // Correct limit for LearnLM
    } else if (modelName.includes('flash-latest') || modelName.includes('1.5-flash')) {
        return 250; // Use 2.5 Flash limit for 1.5 Flash models
    } else if (modelName.includes('pro-latest') || modelName.includes('1.5-pro')) {
        return 50; // Use 2.5 Pro limit for 1.5 Pro models
    }
    
    // Default fallback
    return 1000;
}

// Default model configuration (fallback if API discovery fails)
const DEFAULT_MODEL_CONFIG = [
  {
    name: 'gemini-flash-latest',
    displayName: 'Gemini Flash (Latest)',
    dailyLimit: 1000, // Free tier default
    maxTokens: 1024,
    capabilities: ['text', 'images']
  },
  {
    name: 'gemini-pro-latest',
    displayName: 'Gemini Pro (Latest)',
    dailyLimit: 100, // Free tier default
    maxTokens: 2048,
    capabilities: ['text', 'images', 'long-context']
  },
  {
    name: 'gemini-2.5-flash',
    displayName: 'Gemini 2.5 Flash',
    dailyLimit: 1000, // Free tier default
    maxTokens: 1024,
    capabilities: ['text', 'images']
  },
  {
    name: 'gemini-2.5-pro',
    displayName: 'Gemini 2.5 Pro',
    dailyLimit: 100, // Free tier default
    maxTokens: 2048,
    capabilities: ['text', 'images', 'long-context']
  }
];

// Dynamic model configuration (updated from API)
let MODEL_CONFIG = [...DEFAULT_MODEL_CONFIG];

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('🔵 MESSAGE RECEIVED IN BACKGROUND:', message.type, 'from tab:', sender.tab?.id);
  
  // Always respond to prevent timeout
  if (!sendResponse) {
    console.error('🔴 No sendResponse function provided');
    return;
  }
  
  try {
  if (message.type === 'ANALYZE_CONTENT') {
      console.log('🔵 Calling handleContentAnalysis...');
      handleContentAnalysis(message.data).then((result) => {
        console.log('🔵 handleContentAnalysis completed, sending response:', result);
        if (typeof sendResponse === 'function') {
          sendResponse(result);
        }
      }).catch((error) => {
        console.error('🔴 handleContentAnalysis error:', error);
        if (typeof sendResponse === 'function') {
          sendResponse({ error: error.message });
        }
      });
    return true; // Keep channel open for async response
  } else if (message.type === 'PROCESS_COURSE_RESOURCES') {
    handleResourceProcessing(message.data).then(sendResponse);
    return true; // Keep channel open for async response
  } else if (message.type === 'DISCOVER_MODELS') {
    discoverAvailableModels().then(sendResponse);
    return true; // Keep channel open for async response
  } else if (message.type === 'TEST_API_KEY') {
    testApiKey().then(sendResponse);
    return true; // Keep channel open for async response
  } else if (message.type === 'REFRESH_MODELS') {
    discoverAvailableModels().then(sendResponse);
    return true; // Keep channel open for async response
  } else if (message.type === 'GET_MODEL_CONFIG') {
    sendResponse({ success: true, models: MODEL_CONFIG });
    return true;
  } else if (message.type === 'PING') {
    // Simple ping to test if background script is alive
    console.log('🔵 PING received, responding with PONG');
    sendResponse({ success: true, message: 'PONG' });
    return false; // Synchronous response
  } else if (message.type === 'CAPTURE_SCREENSHOT') {
    // Use Chrome's captureVisibleTab API to take a screenshot
    console.log('CAPTURE_SCREENSHOT request received from content script');
    
    try {
      chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          console.error('Screenshot capture error:', chrome.runtime.lastError);
          console.error('Full error details:', JSON.stringify(chrome.runtime.lastError));
          sendResponse({ screenshot: null, error: chrome.runtime.lastError.message });
        } else if (!dataUrl) {
          console.error('Screenshot captured but dataUrl is empty');
          sendResponse({ screenshot: null, error: 'Empty screenshot data' });
        } else {
          console.log('Screenshot captured successfully, data length:', dataUrl.length);
          // Remove the data:image/png;base64, prefix
          const base64 = dataUrl.split(',')[1];
          console.log('Base64 data length:', base64?.length || 0);
          sendResponse({ screenshot: base64 });
        }
      });
    } catch (error) {
      console.error('Exception during screenshot capture:', error);
      sendResponse({ screenshot: null, error: error.message });
    }
    
    return true; // Keep channel open for async response
  } else {
    // Unknown message type
    console.warn('🔴 Unknown message type:', message.type);
    sendResponse({ error: `Unknown message type: ${message.type}` });
    return false;
  }
  } catch (error) {
    console.error('🔴 Error in message handler:', error);
    sendResponse({ error: error.message });
    return false;
  }
});

// Ensure storage schema exists and has the right shape
async function normalizeStorageSchema() {
  try {
    const stored = await chrome.storage.sync.get('modelUsage');
    console.log('Raw storage data:', stored);
    
    const usage = stored && typeof stored.modelUsage === 'object' && stored.modelUsage !== null
      ? stored.modelUsage
      : {};
    
    // If incoming value wasn't an object, write back normalized shape
    if (!stored || typeof stored.modelUsage !== 'object' || stored.modelUsage === null) {
      console.log('Normalizing corrupted storage...');
      await chrome.storage.sync.set({ modelUsage: usage });
    }
    
    console.log('Normalized usage data:', usage);
    return usage;
  } catch (e) {
    console.error('Storage normalization failed:', e);
    // As a last resort, reset the shape
    try {
      await chrome.storage.sync.set({ modelUsage: {} });
      return {};
    } catch (resetError) {
      console.error('Storage reset failed:', resetError);
      return {};
    }
  }
}

async function handleContentAnalysis({ content, images, screenshot, pageUrl }) {
  try {
    console.log('=== HANDLE CONTENT ANALYSIS CALLED ===');
    console.log('Starting content analysis...', { content, images: images?.length, screenshot: !!screenshot, pageUrl });
    
    console.log('Getting API key from storage...');
    const result = await chrome.storage.sync.get(['geminiApiKey', 'bypassEnabled']);
    console.log('API key retrieved:', result.geminiApiKey ? 'YES' : 'NO');
    
    if (!result.geminiApiKey) {
      return { error: 'API key not configured. Click the extension icon to set it up.' };
    }
    
    // Get current model usage stats (defensive against undefined)
    console.log('Normalizing storage schema...');
    const modelUsage = await normalizeStorageSchema();
    const today = new Date().toDateString();
    
    console.log('Model usage data:', modelUsage);
    console.log('Today:', today);
    
    // Find the best available model
    console.log('Finding available model...');
    const availableModel = findAvailableModel(modelUsage, today, (images?.length || 0) > 0);
    console.log('Available model result:', availableModel);
    
    if (!availableModel) {
      return { error: 'Daily limits reached for all models. Try again tomorrow.' };
    }
    
    console.log('Selected model:', availableModel.name);
    console.log('Building prompt and request...');
    
    // ENHANCED PROMPT - Request confidence levels and alternatives
    const prompt = `Look at the image and text. Answer ALL visible questions.

Content visible: "${content.text}"

If you see multiple questions, answer each one separately.

For surgical instruments:
- Use hints to decode through wordplay, puns, or sound-alikes
- "holiday glad" = sounds like? = Tydings
- "fork and spoon" = Barret-Allen
- "blank scope" = answer "Operative" (NOT "Operative scope")

For other questions:
- Answer directly based on the question
- Use medical/scientific knowledge
- Be specific and accurate

Provide your answer in this EXACT format:

QUESTION 1: [answer] ([confidence%])
QUESTION 2: [answer] ([confidence%])
[etc. for each visible question]

If only one question is visible:
ANSWER: [answer] ([confidence%])

Rules:
- Answer EVERY visible question
- Include confidence percentage for each answer
- Keep answers concise (1-3 words max)
- Do NOT explain or summarize
- If unsure, show confidence below 90%

Your response:`;
    const imageParts = [];
    if (availableModel.capabilities.includes('images')) {
      // Add screenshot first (most important for identification)
      if (screenshot) {
        imageParts.push({ 
          inline_data: { mime_type: 'image/png', data: screenshot } 
        });
      }
      // Add other images from the page
      images.forEach(img => {
        imageParts.push({ 
          inline_data: { mime_type: 'image/png', data: img } 
        });
      });
    }
    
    // Call Gemini API with the selected model
    console.log('=== CALLING GEMINI API ===');
    console.log('URL:', `https://generativelanguage.googleapis.com/v1beta/models/${availableModel.name}:generateContent`);
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${availableModel.name}:generateContent?key=${result.geminiApiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: prompt },
              ...imageParts
            ]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: availableModel.maxTokens,
          }
        })
      }
    );
    
    console.log('=== FETCH COMPLETED ===');
    console.log('Response status:', response.status);
    console.log('Response OK:', response.ok);
    
    // Check if response is ok before parsing JSON
    if (!response.ok) {
      const errorText = await response.text();
      console.error('API request failed:', response.status, response.statusText, errorText);
      return { error: `API request failed: ${response.status} ${response.statusText}` };
    }

    // Get response text first to check if it's valid JSON
    const rawResponseText = await response.text();
    console.log('Raw API response:', rawResponseText);
    
    let data;
    try {
      data = JSON.parse(rawResponseText);
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      console.error('Response text that failed to parse:', rawResponseText);
      return { error: `Failed to parse API response: ${parseError.message}` };
    }
    
    console.log('Full Gemini API response:', JSON.stringify(data, null, 2));
    
    if (data.error) {
      // If quota exceeded or model overloaded, try next model
      if (data.error.message.includes('quota') || data.error.message.includes('limit') || 
          data.error.message.includes('overloaded') || data.error.message.includes('try again later')) {
        console.log(`Model ${availableModel.name} failed: ${data.error.message}, trying fallback...`);
        return await handleContentAnalysisWithFallback({ content, images, screenshot, pageUrl }, availableModel);
      }
      return { error: `API Error: ${data.error.message}` };
    }
    
    // Check for API errors first
    if (data.error) {
      console.log('Gemini API returned error:', data.error);
      return { error: `Gemini API Error: ${data.error.message || data.error}` };
    }
    
    if (!data.candidates || !data.candidates[0]) {
      console.log('No candidates in response:', data);
      return { error: 'No response from Gemini API' };
    }
    
    if (!data.candidates[0].content) {
      console.log('No content in first candidate:', data.candidates[0]);
      return { error: 'No content in Gemini response' };
    }

    // Handle different response structures with comprehensive debugging
    console.log('=== GEMINI API RESPONSE DEBUG ===');
    console.log('Full Gemini API response structure:', JSON.stringify(data, null, 2));
    console.log('Response type:', typeof data);
    console.log('Response keys:', Object.keys(data || {}));
    
    // Check if this is actually an error response
    if (data.error) {
      console.log('Gemini returned an error:', data.error);
      return { error: `Gemini API Error: ${data.error.message || data.error}` };
    }
    
    let responseText = '';
    
    // Try multiple possible response structures
    if (data.candidates && data.candidates[0]) {
      const candidate = data.candidates[0];
      console.log('Candidate structure:', JSON.stringify(candidate, null, 2));
      
      // Check for content.parts[0].text (most common)
      if (candidate.content && candidate.content.parts && candidate.content.parts[0] && candidate.content.parts[0].text) {
        responseText = candidate.content.parts[0].text;
        console.log('Found response in content.parts[0].text');
      }
      // Check for content.text
      else if (candidate.content && candidate.content.text) {
        responseText = candidate.content.text;
        console.log('Found response in content.text');
      }
      // Check for direct text
      else if (candidate.text) {
        responseText = candidate.text;
        console.log('Found response in candidate.text');
      }
      // Check for any text in the candidate object
      else if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        for (const part of candidate.content.parts) {
          if (part.text && part.text.trim()) {
            responseText = part.text.trim();
            console.log('Found response in content.parts array:', responseText);
            break;
          }
        }
      }
      // Check for finishReason and empty content
      else if (candidate.finishReason === 'STOP' && candidate.content && candidate.content.parts && candidate.content.parts.length === 0) {
        responseText = 'No response generated';
        console.log('Found empty response with STOP finishReason');
      }
      // Check for safety issues
      else if (candidate.safetyRatings && candidate.safetyRatings.length > 0) {
        const blocked = candidate.safetyRatings.some(rating => rating.blocked);
        if (blocked) {
          return { error: 'Response blocked by safety filters' };
        }
      }
    }
    
    if (!responseText) {
      console.log('No response text found in any expected location');
      console.log('Full response data:', JSON.stringify(data, null, 2));
      
      // Last resort: try to extract any text from the entire response
      const responseString = JSON.stringify(data);
      const textMatch = responseString.match(/"text":\s*"([^"]+)"/);
      if (textMatch) {
        responseText = textMatch[1];
        console.log('Found text in JSON string:', responseText);
      } else {
        // Try to find any text content in the response
        const anyTextMatch = responseString.match(/"text":\s*"([^"]{10,})"/);
        if (anyTextMatch) {
          responseText = anyTextMatch[1];
          console.log('Found any text in JSON string:', responseText);
        } else {
          // Try to find any text content anywhere in the response
          const anyTextAnywhere = responseString.match(/"text":\s*"([^"]+)"/);
          if (anyTextAnywhere) {
            responseText = anyTextAnywhere[1];
            console.log('Found any text anywhere in JSON string:', responseText);
          } else {
            // Last resort: look for any string that looks like a response
            const responseMatch = responseString.match(/"([A-Za-z0-9\s\.,!?\-]{20,})"/);
            if (responseMatch) {
              responseText = responseMatch[1];
              console.log('Found potential response text:', responseText);
            } else {
              // Final fallback: try to extract any meaningful text
              const anyText = responseString.match(/"([^"]{30,})"/);
              if (anyText) {
                responseText = anyText[1];
                console.log('Found fallback text:', responseText);
              } else {
                console.log('No text found anywhere in response');
                return { error: 'No content parts in Gemini response' };
              }
            }
          }
        }
      }
    }
    
    console.log('Extracted response text:', responseText);
    
    // Update usage count
    await updateModelUsage(availableModel.name, today);
    
    return { 
      answer: responseText,
      model: availableModel.displayName
    };
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    return { error: `Error: ${error.message}` };
  }
}

function findAvailableModel(usageData, today, hasImages) {
  console.log('Finding available model...', { usageData, today, hasImages });
  
  for (const model of MODEL_CONFIG) {
    const modelKey = `${model.name}_${today}`;
    const usage = usageData && typeof usageData === 'object' ? usageData : {};
    const currentUsage = usage[modelKey] || 0;
    
    console.log(`Checking model ${model.name}:`, { modelKey, currentUsage, dailyLimit: model.dailyLimit });
    
    // Skip models that don't support images if we have images
    if (hasImages && !model.capabilities.includes('images')) {
      console.log(`Skipping ${model.name} - doesn't support images`);
      continue;
    }
    
    // Skip models that have reached their daily limit
    if (currentUsage >= model.dailyLimit) {
      console.log(`Skipping ${model.name} - daily limit reached (${currentUsage}/${model.dailyLimit})`);
      continue;
    }
    
    console.log(`Selected model: ${model.name}`);
    return model;
  }
  
  console.log('No available models found');
  return null;
}

async function updateModelUsage(modelName, today) {
  try {
  const modelKey = `${modelName}_${today}`;
    const modelUsage = await normalizeStorageSchema();
    
    console.log('Updating model usage:', { modelName, modelKey, currentUsage: modelUsage[modelKey] });
    
    if (!modelUsage[modelKey]) {
      modelUsage[modelKey] = 0;
    }
    
    modelUsage[modelKey]++;
    
    await chrome.storage.sync.set({ modelUsage });
    console.log('Model usage updated:', modelUsage);
  } catch (error) {
    console.error('Error updating model usage:', error);
  }
}

async function handleContentAnalysisWithFallback({ content, images, screenshot, pageUrl }, failedModel) {
  // Try next available model after the failed one
  const failedIndex = MODEL_CONFIG.findIndex(m => m.name === failedModel.name);
  const nextModels = MODEL_CONFIG.slice(failedIndex + 1);
  
  for (const model of nextModels) {
    try {
      const result = await chrome.storage.sync.get(['geminiApiKey']);
      const modelUsage = await normalizeStorageSchema();
      const today = new Date().toDateString();
      const modelKey = `${model.name}_${today}`;
      const currentUsage = modelUsage[modelKey] || 0;
      
      if (currentUsage >= model.dailyLimit) continue;
      
      // ENHANCED PROMPT - Handle multiple questions
      const prompt = `Look at the image and text. Answer ALL visible questions.

Content visible: "${content.text}"

If you see multiple questions, answer each one separately.

For surgical instruments:
- Use hints to decode through wordplay, puns, or sound-alikes
- "holiday glad" = sounds like? = Tydings
- "fork and spoon" = Barret-Allen
- "blank scope" = answer "Operative" (NOT "Operative scope")

For other questions:
- Answer directly based on the question
- Use medical/scientific knowledge
- Be specific and accurate

Provide your answer in this EXACT format:

QUESTION 1: [answer] ([confidence%])
QUESTION 2: [answer] ([confidence%])
[etc. for each visible question]

If only one question is visible:
ANSWER: [answer] ([confidence%])

Rules:
- Answer EVERY visible question
- Include confidence percentage for each answer
- Keep answers concise (1-3 words max)
- Do NOT explain or summarize
- If unsure, show confidence below 90%

Your response:`;
      
      // Prepare image parts for fallback too
      const imageParts = [];
      if (model.capabilities.includes('images')) {
        if (screenshot) {
          imageParts.push({ 
            inline_data: { mime_type: 'image/png', data: screenshot } 
          });
        }
        images.forEach(img => {
          imageParts.push({ 
            inline_data: { mime_type: 'image/png', data: img } 
          });
        });
      }
      
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model.name}:generateContent?key=${result.geminiApiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [
                { text: prompt },
                ...imageParts
              ]
            }],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: model.maxTokens,
            }
          })
        }
      );
      
      // Check if response is ok before parsing JSON
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Fallback model ${model.name} API request failed:`, response.status, response.statusText, errorText);
        continue; // Try next model
      }

      // Get response text first to check if it's valid JSON
      const fallbackResponseText = await response.text();
      console.log(`Raw fallback API response for ${model.name}:`, fallbackResponseText);
      
      let data;
      try {
        data = JSON.parse(fallbackResponseText);
      } catch (parseError) {
        console.error(`JSON parse error for fallback model ${model.name}:`, parseError);
        console.error('Response text that failed to parse:', fallbackResponseText);
        continue; // Try next model
      }
      
      if (data.error) {
        console.log(`Fallback model ${model.name} failed: ${data.error.message}, trying next...`);
        continue; // Try next model
      }
      
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
        console.log(`Fallback model ${model.name} returned no content, trying next...`);
        continue;
      }

      // Handle different response structures with comprehensive debugging
      console.log(`Fallback model ${model.name} response structure:`, JSON.stringify(data, null, 2));
      
      let responseText = '';
      
      // Try multiple possible response structures
      if (data.candidates && data.candidates[0]) {
        const candidate = data.candidates[0];
        console.log(`Fallback candidate structure for ${model.name}:`, JSON.stringify(candidate, null, 2));
        
        // Check for content.parts[0].text
        if (candidate.content && candidate.content.parts && candidate.content.parts[0] && candidate.content.parts[0].text) {
          responseText = candidate.content.parts[0].text;
          console.log(`Found response in content.parts[0].text for ${model.name}`);
        }
        // Check for content.text
        else if (candidate.content && candidate.content.text) {
          responseText = candidate.content.text;
          console.log(`Found response in content.text for ${model.name}`);
        }
        // Check for direct text
        else if (candidate.text) {
          responseText = candidate.text;
          console.log(`Found response in candidate.text for ${model.name}`);
        }
        // Check for finishReason and empty content
        else if (candidate.finishReason === 'STOP' && candidate.content && candidate.content.parts && candidate.content.parts.length === 0) {
          responseText = 'No response generated';
          console.log(`Found empty response with STOP finishReason for ${model.name}`);
        }
        // Check for safety issues
        else if (candidate.safetyRatings && candidate.safetyRatings.length > 0) {
          const blocked = candidate.safetyRatings.some(rating => rating.blocked);
          if (blocked) {
            console.log(`Fallback model ${model.name} blocked by safety filters, trying next...`);
            continue;
          }
        }
      }
      
      if (!responseText) {
        console.log(`No response text found for fallback model ${model.name}, trying next...`);
        
        // Last resort: try to extract any text from the entire response
        const responseString = JSON.stringify(data);
        const textMatch = responseString.match(/"text":\s*"([^"]+)"/);
        if (textMatch) {
          responseText = textMatch[1];
          console.log(`Found text in JSON string for ${model.name}:`, responseText);
        } else {
          continue;
        }
      }
      
      console.log(`Extracted response text from ${model.name}:`, responseText);
      
      await updateModelUsage(model.name, today);
      
      return { 
        answer: responseText,
        model: model.displayName
      };
    } catch (error) {
      continue; // Try next model
    }
  }
  
  return { error: 'All models have reached their limits or encountered errors.' };
}

// Context menu setup
chrome.runtime.onInstalled.addListener(() => {
  // Create context menu for selected text
  chrome.contextMenus.create({
    id: 'askGemini',
    title: 'Ask Gemini about "%s"',
    contexts: ['selection']
  });
  
  // Create context menu for any page
  chrome.contextMenus.create({
    id: 'askGeminiPage',
    title: 'Ask Gemini about this page',
    contexts: ['page']
  });
  
  // Set default settings
  chrome.storage.sync.set({
    bypassEnabled: true,
    apiKeyConfigured: false
  });

  // Initialize normalized storage shape
  normalizeStorageSchema();
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'askGemini') {
    // Send selected text to content script
    chrome.tabs.sendMessage(tab.id, {
      type: 'ANALYZE_SELECTION',
      text: info.selectionText
    });
  } else if (info.menuItemId === 'askGeminiPage') {
    // Send page analysis request to content script
    chrome.tabs.sendMessage(tab.id, {
      type: 'ANALYZE_PAGE'
    });
  }
});

// Handle keyboard shortcut commands
chrome.commands.onCommand.addListener((command) => {
  if (command === 'ask-gemini') {
    // Get the active tab and send message to content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'ANALYZE_PAGE'
        });
      }
    });
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // This will open the popup, but we can also add logic here if needed
});

// Utility function to check if API key is configured
async function checkApiKeyStatus() {
  const result = await chrome.storage.sync.get('geminiApiKey');
  return !!result.geminiApiKey;
}

// Test API key with a simple request
async function testApiKey() {
  try {
    const result = await chrome.storage.sync.get('geminiApiKey');
    if (!result.geminiApiKey) {
      return { error: 'API key not configured' };
    }

    // Test with a simple request to gemini-1.5-flash
    const testResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${result.geminiApiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: 'Hello, this is a test. Please respond with "API test successful".'
          }]
        }]
      })
    });

    const testData = await testResponse.json();
    
    if (testData.error) {
      return { error: `API test failed: ${testData.error.message}` };
    }
    
    return { success: true, message: 'API key is working correctly' };
  } catch (error) {
    return { error: `API test failed: ${error.message}` };
  }
}

// Function to discover available models and update configuration
async function discoverAvailableModels() {
  try {
    const result = await chrome.storage.sync.get('geminiApiKey');
    if (!result.geminiApiKey) {
      return { error: 'API key not configured' };
    }
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${result.geminiApiKey}`
    );
    
    const data = await response.json();
    
    if (data.error) {
      return { error: data.error.message };
    }
    
    // Update the model configuration with discovered models
    await updateModelConfiguration(data.models || []);
    
    return { 
      success: true, 
      models: data.models || [],
      updatedConfig: MODEL_CONFIG
    };
    
  } catch (error) {
    return { error: error.message };
  }
}

// Update model configuration based on API discovery
async function updateModelConfiguration(discoveredModels) {
  try {
    console.log('Updating model configuration with discovered models:', discoveredModels.length);
    
    // Create a map of discovered models for quick lookup
    const modelMap = new Map();
    discoveredModels.forEach(model => {
      modelMap.set(model.name, model);
    });
    
    // Update MODEL_CONFIG with discovered models, keeping our preferences
    const updatedConfig = [];
    
    // First, add models we prefer in order
    const preferredModels = [
      'gemini-1.5-flash',
      'gemini-1.5-pro', 
      'gemini-1.0-pro',
      'gemini-2.0-flash-exp',
      'gemini-2.0-pro-exp'
    ];
    
    for (const preferredName of preferredModels) {
      if (modelMap.has(preferredName)) {
        const discoveredModel = modelMap.get(preferredName);
        const config = DEFAULT_MODEL_CONFIG.find(m => m.name === preferredName) || {
          name: preferredName,
          displayName: discoveredModel.displayName || preferredName,
          dailyLimit: getModelLimit(preferredName, 'free'),
          maxTokens: 1024,
          capabilities: ['text', 'images']
        };
        
        // Update with discovered model info
        config.displayName = discoveredModel.displayName || config.displayName;
        config.supportedMethods = discoveredModel.supportedGenerationMethods || [];
        
        updatedConfig.push(config);
        console.log(`Added preferred model: ${preferredName}`);
      }
    }
    
    // Add any other discovered models we don't have
    for (const [modelName, model] of modelMap) {
      if (!updatedConfig.find(m => m.name === modelName)) {
        updatedConfig.push({
          name: modelName,
          displayName: model.displayName || modelName,
          dailyLimit: getModelLimit(modelName, 'free'),
          maxTokens: 1024,
          capabilities: ['text', 'images'],
          supportedMethods: model.supportedGenerationMethods || []
        });
        console.log(`Added discovered model: ${modelName}`);
      }
    }
    
    // Update the global configuration
    MODEL_CONFIG = updatedConfig;
    
    // Save to storage for persistence
    await chrome.storage.local.set({
      modelConfig: MODEL_CONFIG,
      lastModelUpdate: Date.now()
    });
    
    console.log('Model configuration updated successfully:', MODEL_CONFIG.length, 'models');
    return MODEL_CONFIG;
    
  } catch (error) {
    console.error('Error updating model configuration:', error);
    return MODEL_CONFIG; // Return current config on error
  }
}

// Load model configuration from storage on startup
async function loadModelConfiguration() {
  try {
    const result = await chrome.storage.local.get(['modelConfig', 'lastModelUpdate']);
    
    // Check if we have a recent configuration (less than 24 hours old)
    const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
    if (result.modelConfig && result.lastModelUpdate && result.lastModelUpdate > oneDayAgo) {
      MODEL_CONFIG = result.modelConfig;
      console.log('Loaded model configuration from storage:', MODEL_CONFIG.length, 'models');
      return MODEL_CONFIG;
    }
    
    // If no recent config, try to discover models
    console.log('No recent model configuration found, discovering models...');
    const discovery = await discoverAvailableModels();
    if (discovery.success) {
      return MODEL_CONFIG;
    }
    
    // Fall back to default if discovery fails
    console.log('Model discovery failed, using default configuration');
    MODEL_CONFIG = [...DEFAULT_MODEL_CONFIG];
    return MODEL_CONFIG;
    
  } catch (error) {
    console.error('Error loading model configuration:', error);
    MODEL_CONFIG = [...DEFAULT_MODEL_CONFIG];
    return MODEL_CONFIG;
  }
}

// Handle resource processing for Moodle course materials
async function handleResourceProcessing(resources) {
  try {
    console.log('Processing course resources:', resources);
    
    // Create a processing request
    const processingRequest = {
      courseInfo: resources.courseInfo,
      resources: {
        powerpoints: resources.powerpoints,
        youtubeVideos: resources.youtubeVideos,
        otherResources: resources.otherResources
      },
      processingId: generateProcessingId(),
      timestamp: new Date().toISOString(),
      status: 'pending'
    };
    
    // Store the processing request
    await chrome.storage.local.set({
      [`processing_${processingRequest.processingId}`]: processingRequest
    });
    
    // Send to StudyAutomation system (you'll need to implement this endpoint)
    const response = await sendToStudyAutomation(processingRequest);
    
    if (response.success) {
      return { 
        success: true, 
        processingId: processingRequest.processingId,
        message: 'Resources queued for processing successfully!'
      };
    } else {
      return { 
        success: false, 
        error: response.error || 'Failed to queue resources for processing'
      };
    }
    
  } catch (error) {
    console.error('Error processing resources:', error);
    return { 
      success: false, 
      error: error.message 
    };
  }
}

function generateProcessingId() {
  return 'proc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

async function sendToStudyAutomation(processingRequest) {
  try {
    // This would be your StudyAutomation system endpoint
    // For now, we'll simulate sending the data
    console.log('Sending to StudyAutomation system:', processingRequest);
    
    // In a real implementation, you would:
    // 1. Send HTTP request to your StudyAutomation backend
    // 2. Include authentication headers
    // 3. Handle the response
    
    // For now, return success
    return { success: true, message: 'Resources queued for processing' };
    
  } catch (error) {
    console.error('Failed to send to StudyAutomation:', error);
    return { success: false, error: error.message };
  }
}

// ============================================================================
// UPDATE SYSTEM
// ============================================================================

const UPDATE_CHECK_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours
const GITHUB_RELEASES_URL = 'https://api.github.com/repos/morgrum/moodle-extension-updates/releases/latest';

let updateCheckTimer = null;

// Initialize update system
function initializeUpdateSystem() {
    console.log('Initializing extension update system...');
    
    // Check for updates on startup (with error handling)
    checkForUpdates().catch(error => {
        console.log('Update check failed:', error.message);
    });
    
    // Set up periodic update checks
    updateCheckTimer = setInterval(() => {
        checkForUpdates().catch(error => {
            console.log('Periodic update check failed:', error.message);
        });
    }, UPDATE_CHECK_INTERVAL);
}

// Check for available updates
async function checkForUpdates() {
    try {
        console.log('Checking for updates from GitHub releases...');
        
        const response = await fetch(GITHUB_RELEASES_URL);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const release = await response.json();
        console.log('Latest release received:', release);
        
        const currentVersion = await getCurrentVersion();
        const latestVersion = release.tag_name.replace('v', ''); // Remove 'v' prefix if present
        
        // Store latest version for UI to check
        await chrome.storage.local.set({ 
            latestVersion: latestVersion,
            lastUpdateCheck: Date.now()
        });
        
        if (compareVersions(latestVersion, currentVersion) > 0) {
            console.log(`Update available: ${currentVersion} -> ${latestVersion}`);
            return { 
                updateAvailable: true, 
                latestVersion, 
                currentVersion,
                updateUrl: release.html_url,
                downloadUrl: release.assets[0]?.browser_download_url || release.html_url
            };
        } else {
            console.log('Extension is up to date (version:', currentVersion, ')');
            return { updateAvailable: false, currentVersion };
        }
        
    } catch (error) {
        console.error('Error checking for updates:', error);
        return { updateAvailable: false, error: error.message };
    }
}

// Download and install updates
async function downloadUpdate(updateManifest) {
    try {
        console.log('Downloading update from manifest:', updateManifest);
        
        if (!updateManifest.resources || !updateManifest.resources.extension) {
            throw new Error('Invalid update manifest: missing extension resource');
        }
        
        // Download the extension ZIP file
        const extensionUrl = updateManifest.resources.extension.url;
        console.log('Downloading extension from:', extensionUrl);
        
        const response = await fetch(extensionUrl);
        if (!response.ok) {
            throw new Error(`Failed to download extension: ${response.status} ${response.statusText}`);
        }
        
        const extensionBlob = await response.blob();
        console.log('Extension downloaded, size:', extensionBlob.size, 'bytes');
        
        // Download additional resources if available
        const additionalResources = {};
        
        if (updateManifest.resources.processor) {
            try {
                const processorResponse = await fetch(updateManifest.resources.processor.url);
                if (processorResponse.ok) {
                    additionalResources.processor = await processorResponse.text();
                    console.log('Processor downloaded');
                }
            } catch (e) {
                console.log('Failed to download processor:', e.message);
            }
        }
        
        if (updateManifest.resources.batch_file) {
            try {
                const batchResponse = await fetch(updateManifest.resources.batch_file.url);
                if (batchResponse.ok) {
                    additionalResources.batch = await batchResponse.text();
                    console.log('Batch file downloaded');
                }
            } catch (e) {
                console.log('Failed to download batch file:', e.message);
            }
        }
        
        // Store the update data for manual installation
        await chrome.storage.local.set({
            pendingUpdate: {
                version: updateManifest.version,
                extensionBlob: await extensionBlob.arrayBuffer(),
                resources: additionalResources,
                downloadTime: Date.now()
            }
        });
        
        console.log('Update downloaded and stored for manual installation');
        
        return { success: true, version: updateManifest.version, requiresManualInstall: true };
        
    } catch (error) {
        console.error('Error downloading update:', error);
        return { success: false, error: error.message };
    }
}

// Get current version
async function getCurrentVersion() {
    // Always use the manifest version as the source of truth
    const manifest = chrome.runtime.getManifest();
    const manifestVersion = manifest.version || '1.0.0';
    
    // Update storage to match manifest version
    await chrome.storage.local.set({ extensionVersion: manifestVersion });
    
    return manifestVersion;
}

// Update version
async function updateVersion(version) {
    await chrome.storage.local.set({ extensionVersion: version });
}

// Compare version strings
function compareVersions(version1, version2) {
    const v1parts = version1.split('.').map(Number);
    const v2parts = version2.split('.').map(Number);
    
    for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
        const v1part = v1parts[i] || 0;
        const v2part = v2parts[i] || 0;
        
        if (v1part > v2part) return 1;
        if (v1part < v2part) return -1;
    }
    
    return 0;
}

// Add update message handlers to existing listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'CHECK_FOR_UPDATES') {
        checkForUpdates().then(sendResponse);
        return true;
    } else if (message.type === 'UPDATE_NOW') {
        checkForUpdates()
            .then(response => {
                if (response.updateAvailable) {
                    // Open GitHub releases page for manual update
                    chrome.tabs.create({ url: response.updateUrl });
                    sendResponse({ 
                        success: true, 
                        message: 'Opening GitHub releases page for manual update',
                        updateUrl: response.updateUrl
                    });
                } else {
                    sendResponse({ 
                        success: false, 
                        message: 'No updates available' 
                    });
                }
            })
            .catch(error => {
                sendResponse({ 
                    success: false, 
                    error: error.message 
                });
            });
        return true;
    } else if (message.type === 'GET_MODEL_CONFIG') {
        sendResponse({ models: MODEL_CONFIG });
        return true;
    } else if (message.type === 'GET_EXHAUSTED_MODELS') {
        sendResponse({ exhaustedModels: exhaustedModels });
        return true;
    }
});

// Track exhausted models for the current day
let exhaustedModels = {}; // { 'model-name': 'YYYY-MM-DD' }

// Get available models (excluding exhausted ones)
async function getAvailableModels() {
    const today = new Date().toDateString();
    const allModels = await getModelConfigurations();
    
    return allModels.filter(model => {
        const isExhausted = exhaustedModels[model.name] === today;
        if (isExhausted) {
            console.log(`Model ${model.name} is exhausted for today. Skipping.`);
        }
        return !isExhausted;
    });
}

// Mark a model as exhausted for today
function markModelExhausted(modelName) {
    const today = new Date().toDateString();
    exhaustedModels[modelName] = today;
    console.log(`Marked ${modelName} as exhausted for ${today}`);
}

// Initialize systems on startup
initializeUpdateSystem();
loadModelConfiguration();