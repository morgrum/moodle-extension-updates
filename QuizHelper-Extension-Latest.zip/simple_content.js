// Simple working content script
console.log('Simple extension loaded!');

// Test keyboard shortcut
document.addEventListener('keydown', function(e) {
  console.log('Key pressed:', e.key, 'Ctrl:', e.ctrlKey, 'Shift:', e.shiftKey);
  
  if (e.ctrlKey && e.shiftKey && e.key === 'G') {
    console.log('Ctrl+Shift+G detected!');
    e.preventDefault();
    e.stopPropagation();
    
    // Show a simple alert to test
    alert('Extension is working! Ctrl+Shift+G detected.');
  }
});
