// Options page script for QuizHelper Chrome Extension

// Hardcoded API key for convenience
const DEFAULT_API_KEY = 'AIzaSyCbIRJYM7jNE67vx7HQj4eMfZFm80F68dE';

document.addEventListener('DOMContentLoaded', async () => {
  // Load current settings
  const result = await chrome.storage.sync.get(['geminiApiKey', 'bypassEnabled']);
  
  // Populate form fields
  const apiKeyInput = document.getElementById('apiKey');
  const bypassToggle = document.getElementById('bypassEnabled');
  const saveButton = document.getElementById('saveApiKey');
  const statusDiv = document.getElementById('apiStatus');
  
  if (result.geminiApiKey) {
    apiKeyInput.value = result.geminiApiKey;
  }
  
  bypassToggle.checked = result.bypassEnabled !== false; // Default to true
  
  // Handle API key save
  saveButton.addEventListener('click', async () => {
    const apiKey = apiKeyInput.value.trim();
    
    if (!apiKey) {
      showStatus('Please enter an API key', 'error');
      return;
    }
    
    // Basic validation - Gemini API keys typically start with "AIza"
    if (!apiKey.startsWith('AIza')) {
      showStatus('Invalid API key format. Gemini API keys typically start with "AIza"', 'error');
      return;
    }
    
    try {
      // Save to Chrome storage
      await chrome.storage.sync.set({
        geminiApiKey: apiKey,
        apiKeyConfigured: true
      });
      
      showStatus('✅ API key saved successfully!', 'success');
      
      // Test the API key
      testApiKey(apiKey);
      
    } catch (error) {
      showStatus('❌ Failed to save API key: ' + error.message, 'error');
    }
  });
  
  // Handle bypass toggle
  bypassToggle.addEventListener('change', async () => {
    try {
      await chrome.storage.sync.set({
        bypassEnabled: bypassToggle.checked
      });
      
      const status = bypassToggle.checked ? 'enabled' : 'disabled';
      showStatus(`Moodle bypass ${status}`, 'success');
      
      // Clear status after 2 seconds
      setTimeout(() => {
        hideStatus();
      }, 2000);
      
    } catch (error) {
      showStatus('Failed to save setting: ' + error.message, 'error');
    }
  });
  
  // Auto-save API key when typing stops
  let saveTimeout;
  apiKeyInput.addEventListener('input', () => {
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => {
      if (apiKeyInput.value.trim()) {
        saveButton.click();
      }
    }, 1000);
  });
});

function showStatus(message, type) {
  const statusDiv = document.getElementById('apiStatus');
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  statusDiv.style.display = 'block';
}

function hideStatus() {
  const statusDiv = document.getElementById('apiStatus');
  statusDiv.style.display = 'none';
}

async function testApiKey(apiKey) {
  try {
    showStatus('🔍 Testing API key...', 'info');
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: "Hello, this is a test message. Please respond with 'API key is working!'" }]
          }],
          generationConfig: {
            maxOutputTokens: 50,
            temperature: 0.1
          }
        })
      }
    );
    
    const data = await response.json();
    
    if (data.error) {
      showStatus('❌ API key test failed: ' + data.error.message, 'error');
    } else if (data.candidates && data.candidates[0]) {
      showStatus('✅ API key is working correctly!', 'success');
    } else {
      showStatus('❌ API key test failed: No response from API', 'error');
    }
    
  } catch (error) {
    showStatus('❌ API key test failed: ' + error.message, 'error');
  }
}

