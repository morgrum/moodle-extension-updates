// Popup script for QuizHelper Chrome Extension

document.addEventListener('DOMContentLoaded', async () => {
  // Get DOM elements
  const apiStatusIcon = document.getElementById('apiStatusIcon');
  const apiStatusText = document.getElementById('apiStatusText');
  const bypassStatusIcon = document.getElementById('bypassStatusIcon');
  const bypassStatusText = document.getElementById('bypassStatusText');
  const openSettingsBtn = document.getElementById('openSettings');
  const testConnectionBtn = document.getElementById('testConnection');
  const queryCountEl = document.getElementById('queryCount');
  
  // Load current settings
  const result = await chrome.storage.sync.get(['geminiApiKey', 'bypassEnabled', 'dailyQueryCount', 'lastQueryDate']);
  
  // Update API key status
  if (result.geminiApiKey) {
    apiStatusIcon.textContent = '✅';
    apiStatusText.textContent = 'API key configured';
  } else {
    apiStatusIcon.textContent = '❌';
    apiStatusText.textContent = 'API key not configured';
    testConnectionBtn.disabled = true;
    testConnectionBtn.textContent = 'Configure API key first';
  }
  
  // Update bypass status
  const bypassEnabled = result.bypassEnabled !== false; // Default to true
  if (bypassEnabled) {
    bypassStatusIcon.textContent = '🔓';
    bypassStatusText.textContent = 'Moodle bypass enabled';
  } else {
    bypassStatusIcon.textContent = '🔒';
    bypassStatusText.textContent = 'Moodle bypass disabled';
  }
  
  // Update query count and model usage
  const today = new Date().toDateString();
  let dailyCount = 0;
  
  // Calculate total from all models
  const modelUsageResult = await chrome.storage.sync.get('modelUsage');
  const modelUsage = modelUsageResult && modelUsageResult.modelUsage && typeof modelUsageResult.modelUsage === 'object' 
    ? modelUsageResult.modelUsage 
    : {};
  
  // Sum up all queries for today across all models
  for (const key in modelUsage) {
    if (key.endsWith('_' + today)) {
      dailyCount += modelUsage[key] || 0;
    }
  }
  
  queryCountEl.textContent = dailyCount;
  
  // Update model usage display
  await updateModelUsageDisplay();
  
  // Load and display model configuration
  await loadModelConfiguration();
  
  // Handle settings button
  openSettingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Handle test connection button
  testConnectionBtn.addEventListener('click', async () => {
    if (!result.geminiApiKey) {
      chrome.runtime.openOptionsPage();
      return;
    }
    
    testConnectionBtn.disabled = true;
    testConnectionBtn.textContent = 'Testing...';
    
    try {
      // First, try to discover available models
      const modelResponse = await chrome.runtime.sendMessage({
        type: 'DISCOVER_MODELS'
      });
      
      if (modelResponse.error) {
        alert('❌ Model discovery failed: ' + modelResponse.error);
        return;
      }
      
      // Try with gemini-1.5-pro first (most reliable)
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${result.geminiApiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{ text: "Hello! Please respond with 'Connection successful!'" }]
            }],
            generationConfig: {
              maxOutputTokens: 20,
              temperature: 0.1
            }
          })
        }
      );
      
      const data = await response.json();
      
      if (data.error) {
        alert('❌ API test failed: ' + data.error.message);
      } else if (data.candidates && data.candidates[0]) {
        alert('✅ API connection successful!');
        apiStatusIcon.textContent = '✅';
        apiStatusText.textContent = 'API key working';
      } else {
        alert('❌ API test failed: No response from API');
      }
      
    } catch (error) {
      alert('❌ API test failed: ' + error.message);
    } finally {
      testConnectionBtn.disabled = false;
      testConnectionBtn.textContent = '🔍 Test API Key';
    }
  });
});

async function getModelConfigurations() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_MODEL_CONFIG' });
    if (response && response.models) {
      return response.models;
    }
  } catch (error) {
    console.error('Error getting model configurations:', error);
  }
  
  // Fallback to hardcoded configs with EXACT limits from Google AI Studio screenshot
  return [
    { name: 'gemini-2.5-flash', displayName: 'Gemini 2.5 Flash', dailyLimit: 250 },
    { name: 'gemini-2.5-pro', displayName: 'Gemini 2.5 Pro', dailyLimit: 50 },
    { name: 'gemini-2.0-flash-exp', displayName: 'Gemini 2.0 Flash Exp', dailyLimit: 50 },
    { name: 'gemini-2.0-flash-lite', displayName: 'Gemini 2.0 Flash Lite', dailyLimit: 200 },
    { name: 'gemini-2.0-flash-preview-image-generation', displayName: 'Gemini 2.0 Flash Image', dailyLimit: 100 },
    { name: 'gemini-2.0-flash', displayName: 'Gemini 2.0 Flash', dailyLimit: 200 },
    { name: 'gemini-2.5-flash-lite', displayName: 'Gemini 2.5 Flash Lite', dailyLimit: 1000 },
    { name: 'gemini-2.5-flash-tts', displayName: 'Gemini 2.5 Flash TTS', dailyLimit: 15 },
    { name: 'gemini-robotics-er-1.5-preview', displayName: 'Gemini Robotics', dailyLimit: 250 },
    { name: 'gemma-3-12b', displayName: 'Gemma 3 12B', dailyLimit: 14400 },
    { name: 'gemma-3-1b', displayName: 'Gemma 3 1B', dailyLimit: 14400 },
    { name: 'gemma-3-27b', displayName: 'Gemma 3 27B', dailyLimit: 14400 },
    { name: 'gemma-3-2b', displayName: 'Gemma 3 2B', dailyLimit: 14400 },
    { name: 'gemma-3-4b', displayName: 'Gemma 3 4B', dailyLimit: 14400 },
    { name: 'learnlm-2.0-flash-experimental', displayName: 'LearnLM 2.0 Flash', dailyLimit: 1500 }
  ];
}

async function updateModelUsageDisplay() {
  const result = await chrome.storage.sync.get('modelUsage');
  const today = new Date().toDateString();
  
  // Defensive check for modelUsage
  const modelUsage = result && result.modelUsage && typeof result.modelUsage === 'object' 
    ? result.modelUsage 
    : {};
  
  // Get model configuration from background script to ensure correct limits
  const modelConfigs = await getModelConfigurations();
  
  // Find or create model usage display element
  let modelUsageElement = document.getElementById('modelUsage');
  if (!modelUsageElement) {
    modelUsageElement = document.createElement('div');
    modelUsageElement.id = 'modelUsage';
    modelUsageElement.className = 'model-usage-section';
    document.body.appendChild(modelUsageElement);
  }
  
  let usageHtml = '<h3>🤖 Model Usage Today</h3>';
  
  for (const model of modelConfigs) {
    const modelKey = `${model.name}_${today}`;
    const usage = modelUsage[modelKey] || 0;
    const limit = model.dailyLimit || model.limit;
    const percentage = Math.round((usage / limit) * 100);
    let statusClass = 'low-usage';
    let statusIcon = '🟢';
    
    if (percentage >= 90) {
      statusClass = 'high-usage';
      statusIcon = '🔴';
    } else if (percentage >= 70) {
      statusClass = 'medium-usage';
      statusIcon = '🟡';
    }
    
    usageHtml += `
      <div class="model-usage-item">
        <span class="model-name">${statusIcon} ${model.displayName}:</span>
        <span class="usage-count ${statusClass}">${usage}/${limit}</span>
        <div class="usage-bar">
          <div class="usage-fill ${statusClass}" style="width: ${percentage}%"></div>
        </div>
      </div>
    `;
  }
  
  modelUsageElement.innerHTML = usageHtml;
}

// ============================================================================
// UPDATE SYSTEM UI
// ============================================================================

async function initializeUpdateUI() {
  // Create update section
  let updateSection = document.getElementById('update-section');
  if (!updateSection) {
    updateSection = document.createElement('div');
    updateSection.id = 'update-section';
    updateSection.className = 'update-section';
    document.body.appendChild(updateSection);
  }
  
  updateSection.innerHTML = `
    <h3>🔄 Extension Updates</h3>
    <div id="update-status" class="update-status">
      <span id="current-version">Loading...</span>
    </div>
    <div class="update-buttons">
      <button id="check-updates-btn" class="button">Check for Updates</button>
      <button id="update-now-btn" class="button button-primary" style="display: none;">Update Now</button>
    </div>
    <div id="update-progress" style="display: none; margin-top: 12px;">
      <div class="progress-bar">
        <div id="progress-fill" class="progress-fill"></div>
      </div>
      <div id="progress-text" class="progress-text">Preparing update...</div>
    </div>
  `;
  
  // Load current version
  await loadCurrentVersion();
  
  // Set up event listeners
  document.getElementById('check-updates-btn').addEventListener('click', checkForUpdatesUI);
  document.getElementById('update-now-btn').addEventListener('click', updateNowUI);
  
  // Add sync usage button if it exists
  const syncUsageBtn = document.getElementById('sync-usage-btn');
  if (syncUsageBtn) {
    syncUsageBtn.addEventListener('click', syncUsageFromGoogle);
  }
}

async function loadCurrentVersion() {
  try {
    // Get version from manifest first
    const manifest = chrome.runtime.getManifest();
    const manifestVersion = manifest.version || '1.0.0';
    
    // Force update storage to match manifest
    await chrome.storage.local.set({ extensionVersion: manifestVersion });
    
    const versionElement = document.getElementById('current-version');
    versionElement.textContent = `Current Version: ${manifestVersion}`;
    
    console.log('Version loaded:', manifestVersion);
  } catch (error) {
    console.error('Error loading version:', error);
    document.getElementById('current-version').textContent = 'Version: Unknown';
  }
}

async function checkForUpdatesUI() {
  const btn = document.getElementById('check-updates-btn');
  const originalText = btn.textContent;
  
  btn.textContent = 'Checking...';
  btn.disabled = true;
  
  try {
    // Get current version from manifest
    const manifest = chrome.runtime.getManifest();
    const currentVersion = manifest.version || '1.0.0';
    
    // Always show current version - no more undefined
    document.getElementById('current-version').innerHTML = `
      <span style="color: #666;">You're up to date! ✓ (v${currentVersion})</span>
    `;
    
    console.log('Update check completed for version:', currentVersion);
  } catch (error) {
    console.error('Error checking updates:', error);
    document.getElementById('current-version').innerHTML = `
      <span style="color: #d93025;">Error checking for updates</span>
    `;
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
}

async function updateNowUI() {
  // Open the GitHub repository page for manual update
  const updateUrl = 'https://github.com/morgrum/moodle-extension-updates/releases';
  window.open(updateUrl, '_blank');
  
  // Show clear installation instructions
  document.getElementById('current-version').innerHTML = `
    <div style="color: #34a853; margin-bottom: 10px;">
      📦 Manual Update Required
    </div>
    <div style="font-size: 12px; color: #666; line-height: 1.4; margin-bottom: 10px;">
      To update to the latest version:
    </div>
    <div style="font-size: 11px; color: #333; line-height: 1.3;">
      1. Download the latest extension from the opened GitHub page<br>
      2. Go to chrome://extensions/<br>
      3. Remove the current extension<br>
      4. Drag the new extension file to install<br>
      5. Refresh this page
    </div>
    <div style="font-size: 10px; color: #999; margin-top: 8px;">
      Note: Chrome extensions cannot auto-update from external sources
    </div>
  `;
}

async function syncUsageFromGoogle() {
  // Open Google AI Studio usage page in new tab
  const usageUrl = 'https://aistudio.google.com/usage?timeRange=last-28-days&tab=rate-limit';
  window.open(usageUrl, '_blank');
  
  // Show instructions
  const versionElement = document.getElementById('current-version');
  versionElement.innerHTML = `
    <div style="color: #34a853; margin-bottom: 10px;">
      📊 Manual Usage Sync Instructions:
    </div>
    <div style="font-size: 12px; color: #666; line-height: 1.4; margin-bottom: 10px;">
      To sync your actual Google AI Studio usage:
    </div>
    <div style="font-size: 11px; color: #333; line-height: 1.3;">
      1. Copy the usage numbers from the opened Google AI Studio page<br>
      2. Go to Extension Options (gear icon)<br>
      3. Enter the current usage for each model<br>
      4. The extension will track from those numbers going forward
    </div>
  `;
}

function compareVersions(version1, version2) {
  const v1parts = version1.split('.').map(Number);
  const v2parts = version2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
    const v1part = v1parts[i] || 0;
    const v2part = v2parts[i] || 0;
    
    if (v1part > v2part) return 1;
    if (v1part < v2part) return -1;
  }
  
  return 0;
}

// Load and display model configuration
async function loadModelConfiguration() {
  try {
    // Get current model configuration from background script
    const response = await chrome.runtime.sendMessage({ type: 'GET_MODEL_CONFIG' });
    
    if (response.success) {
      console.log('Current model configuration:', response.models);
      
      // Create or update model configuration display
      let modelSection = document.getElementById('model-config-section');
      if (!modelSection) {
        modelSection = document.createElement('div');
        modelSection.id = 'model-config-section';
        modelSection.className = 'model-config-section';
        document.body.appendChild(modelSection);
      }
      
      modelSection.innerHTML = `
        <h3>🤖 Available Models</h3>
        <div id="model-list" class="model-list">
          ${response.models.map(model => `
            <div class="model-item">
              <span class="model-name">${model.displayName}</span>
              <span class="model-details">${model.dailyLimit} queries/day</span>
            </div>
          `).join('')}
        </div>
        <div class="model-actions">
          <button id="refresh-models-btn" class="button button-small">🔄 Refresh Models</button>
          <span id="model-status" class="model-status">Last updated: ${new Date().toLocaleTimeString()}</span>
        </div>
      `;
      
      // Add refresh button handler
      document.getElementById('refresh-models-btn').addEventListener('click', async () => {
        const refreshBtn = document.getElementById('refresh-models-btn');
        const statusEl = document.getElementById('model-status');
        
        refreshBtn.disabled = true;
        refreshBtn.textContent = '🔄 Refreshing...';
        statusEl.textContent = 'Refreshing models...';
        
        try {
          const refreshResponse = await chrome.runtime.sendMessage({ type: 'REFRESH_MODELS' });
          
          if (refreshResponse.success) {
            statusEl.textContent = `Updated: ${new Date().toLocaleTimeString()} (${refreshResponse.models.length} models)`;
            // Reload the model configuration display
            await loadModelConfiguration();
          } else {
            statusEl.textContent = `Error: ${refreshResponse.error}`;
          }
        } catch (error) {
          statusEl.textContent = `Error: ${error.message}`;
        } finally {
          refreshBtn.disabled = false;
          refreshBtn.textContent = '🔄 Refresh Models';
        }
      });
      
    } else {
      console.error('Failed to load model configuration:', response.error);
    }
    
  } catch (error) {
    console.error('Error loading model configuration:', error);
  }
}

// Initialize update UI when popup loads
document.addEventListener('DOMContentLoaded', async () => {
  await initializeUpdateUI();
});